# CATAT SMART V3 Native
Native Android build. No WebView is used for the main application UI.

Version: 1.2.0 / versionCode 3

The app stores its data in native SharedPreferences and exports a real XLSX workbook to Downloads.
