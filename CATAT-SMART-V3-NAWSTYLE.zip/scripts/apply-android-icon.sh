#!/usr/bin/env bash
set -euo pipefail

ICON="public/icon-512.png"
if [ ! -f "$ICON" ]; then
  echo "ERROR: $ICON tidak ditemukan."
  exit 1
fi

RES="android/app/src/main/res"
mkdir -p "$RES/drawable" \
  "$RES/mipmap-mdpi" "$RES/mipmap-hdpi" "$RES/mipmap-xhdpi" \
  "$RES/mipmap-xxhdpi" "$RES/mipmap-xxxhdpi" \
  "$RES/mipmap-anydpi-v26" "$RES/values"

# Legacy launcher resources: use the exact same blue book+pen artwork.
for d in mipmap-mdpi mipmap-hdpi mipmap-xhdpi mipmap-xxhdpi mipmap-xxxhdpi; do
  cp "$ICON" "$RES/$d/ic_launcher.png"
  cp "$ICON" "$RES/$d/ic_launcher_round.png"
done

# Keep the exact same finished PNG for both launcher resources.
# This intentionally avoids a second vector/adaptive artwork that could look
# different from the logo shown inside the app.
rm -rf "$RES/mipmap-anydpi-v26"

echo 'CATAT SMART launcher icons updated with blue book+pen logo.'
