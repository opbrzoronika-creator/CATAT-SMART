#!/usr/bin/env bash
set -euo pipefail
mkdir -p android/app/src/main/res/mipmap-mdpi android/app/src/main/res/mipmap-hdpi android/app/src/main/res/mipmap-xhdpi android/app/src/main/res/mipmap-xxhdpi android/app/src/main/res/mipmap-xxxhdpi
cp public/icon-512.png android/app/src/main/res/mipmap-mdpi/ic_launcher.png
cp public/icon-512.png android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png
cp public/icon-512.png android/app/src/main/res/mipmap-hdpi/ic_launcher.png
cp public/icon-512.png android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png
cp public/icon-512.png android/app/src/main/res/mipmap-xhdpi/ic_launcher.png
cp public/icon-512.png android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png
cp public/icon-512.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png
cp public/icon-512.png android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png
cp public/icon-512.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png
cp public/icon-512.png android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png
printf '%s\n' 'CATAT SMART launcher icons updated.'
