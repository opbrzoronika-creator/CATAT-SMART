import React,{useState,useEffect,useRef,useMemo} from 'react';
import * as ExcelJS from 'exceljs';
import { Capacitor, registerPlugin } from '@capacitor/core';
import './index.css';

const NativeFile=registerPlugin('NativeFile');
window.ExcelJS=ExcelJS;



const KEY='catat_smart_data_v2',PIN_KEY='catat_smart_pin_v2',DARK_KEY='catat_smart_dark_v2';
const EXAMS=[
{id:'uh1',label:'Ulangan Harian 1',short:'UH1'},{id:'uh2',label:'Ulangan Harian 2',short:'UH2'},
{id:'uh3',label:'Ulangan Harian 3',short:'UH3'},{id:'uts',label:'Ujian Tengah Semester',short:'UTS'},
{id:'uh4',label:'Ulangan Harian 4',short:'UH4'},{id:'uh5',label:'Ulangan Harian 5',short:'UH5'},
{id:'uh6',label:'Ulangan Harian 6',short:'UH6'},{id:'uas',label:'Ujian Akhir Semester',short:'UAS'}];
const store={load(){try{return JSON.parse(localStorage.getItem(KEY))}catch(e){return null}},save(d){try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}};
const avg=s=>{const v=EXAMS.map(e=>parseFloat(s[e.id])).filter(n=>!isNaN(n));return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
const fmt=n=>n===null||n===undefined?'-':(Math.round(n*10)/10).toString();
const tm=()=>new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
const welcome=n=>`Halo! 👋 Aku asisten CATAT SMART.\n\nAda ${n} murid siap dinilai. Ketik formatnya, contoh:\n• "Andi uh1 85"\n• "Siti uts 90, Budi uas 100"\n\n📋 Sekelas sekaligus (tempel/ketik banyak baris):\nUH1\nAndi 85\nSiti 90\nBudi 78\n\nAtau: "uh1: Andi 85, Siti 90, Budi 78"\n\nLainnya:\n• "hapus Andi uh1"\n• "rata-rata Andi"`;

const ModalWrapper=({title,onClose,children})=>(
<div className="fixed inset-0 bg-black/50 z-[100] flex items-end sm:items-center justify-center" onClick={onClose}>
<div className="bg-white dark:bg-gray-800 dark:text-gray-100 rounded-t-2xl sm:rounded-2xl w-full sm:max-w-sm max-h-[85vh] overflow-y-auto modal-rise" onClick={e=>e.stopPropagation()}>
<div className="flex justify-between items-center p-4 border-b border-gray-100 dark:border-gray-700 sticky top-0 bg-white dark:bg-gray-800">
<h3 className="font-bold">{title}</h3><button onClick={onClose} className="text-xl px-2">✕</button></div>
<div className="p-4 space-y-3">{children}</div></div></div>);
const inputCls="w-full bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-light";
const btnCls="w-full bg-brand-light text-white rounded-lg py-2.5 text-sm font-medium";

const Frame=({dark,children})=>(<div className={dark?'dark':''}><div className="h-screen w-full flex justify-center bg-gray-200 dark:bg-black sm:p-4">{children}</div></div>);

function App(){
const [ready,setReady]=useState(false);
const [students,setStudents]=useState([]);
const [messages,setMessages]=useState([]);
const [hasSetup,setHasSetup]=useState(false);
const [tab,setTab]=useState('chat');
const [text,setText]=useState('');
const [namesInput,setNamesInput]=useState('');
const [dark,setDark]=useState(()=>{try{return localStorage.getItem(DARK_KEY)==='1'}catch(e){return false}});
const [menu,setMenu]=useState(false);
const [editing,setEditing]=useState(null);
const [pin,setPin]=useState(()=>{try{return localStorage.getItem(PIN_KEY)}catch(e){return null}});
const [locked,setLocked]=useState(()=>{try{return !!localStorage.getItem(PIN_KEY)}catch(e){return false}});
const [pinIn,setPinIn]=useState('');const [pinErr,setPinErr]=useState('');
const [showPin,setShowPin]=useState(false);const [pinForm,setPinForm]=useState({p1:'',p2:''});
const [info,setInfo]=useState({kelas:'',mapel:'',semester:''});const [showInfo,setShowInfo]=useState(false);const [infoForm,setInfoForm]=useState({kelas:'',mapel:'',semester:''});
const [showAdd,setShowAdd]=useState(false);const [addNames,setAddNames]=useState('');
const endRef=useRef(null),menuRef=useRef(null),fileRef=useRef(null);

useEffect(()=>{const d=store.load();if(d){setStudents(d.students||[]);setMessages(d.messages||[]);setHasSetup(!!d.hasSetup);setInfo(d.info||{kelas:'',mapel:'',semester:''})}setReady(true)},[]);
useEffect(()=>{if(ready&&hasSetup)store.save({students,messages:messages.slice(-200),hasSetup,info})},[students,messages,hasSetup,ready,info]);
useEffect(()=>{try{localStorage.setItem(DARK_KEY,dark?'1':'0')}catch(e){}},[dark]);
useEffect(()=>{endRef.current?.scrollIntoView({behavior:'smooth'})},[messages,tab]);
useEffect(()=>{const h=e=>{if(menuRef.current&&!menuRef.current.contains(e.target))setMenu(false)};document.addEventListener('mousedown',h);document.addEventListener('touchstart',h);return()=>{document.removeEventListener('mousedown',h);document.removeEventListener('touchstart',h)}},[]);

const mkStudents=(names,start=0)=>names.map((name,i)=>{const s={id:Date.now()+i+start,name};EXAMS.forEach(e=>s[e.id]='');return s});
const handleSetup=()=>{
const names=namesInput.split('\n').map(n=>n.trim()).filter(Boolean);
if(!names.length){alert('Masukkan minimal 1 nama murid!');return}
setStudents(mkStudents(names));setMessages([{id:'init',text:welcome(names.length),sender:'bot',time:tm()}]);setHasSetup(true)};

const findStudent=q=>{q=q.trim().toLowerCase();if(!q)return{err:'Nama muridnya siapa?'};
const m=students.filter(s=>s.name.toLowerCase().includes(q));
if(m.length===1)return{s:m[0]};
if(m.length>1){const ex=m.find(s=>s.name.toLowerCase()===q);if(ex)return{s:ex};return{err:`"${q}" cocok dengan: ${m.map(s=>s.name).join(', ')}. Ketik lebih lengkap.`}}
return{err:`Murid "${q}" tidak ditemukan.`}};
const examOf=c=>c.match(/\b(uh\s*[1-6]|uts|uas)\b/i);

const process=raw=>{
const updates=[],replies=[],removes=[];let cur=null;
raw.split(/[,;\n]/).forEach(cmd=>{
const c=cmd.trim();if(!c)return;
const rm=c.match(/^(hapus|del|delete)\s+(.+)$/i);
if(rm){const ex=examOf(rm[2]);if(!ex){replies.push(`❌ "${c}": Sebutkan ujiannya (cth: hapus Andi uh1)`);return}
const r=findStudent(rm[2].replace(ex[0],' '));if(r.err){replies.push('❌ '+r.err);return}
removes.push({id:r.s.id,name:r.s.name,ex:ex[0].toLowerCase().replace(/\s/g,'')});return}
const av=c.match(/^(rata[- ]?rata|rerata|avg)\s+(.+)$/i);
if(av){const r=findStudent(av[2]);if(r.err){replies.push('❌ '+r.err);return}
const a=avg(r.s);replies.push(a===null?`ℹ️ ${r.s.name} belum punya nilai.`:`📈 Rata-rata ${r.s.name}: ${fmt(a)}`);return}
const norm=x=>x[0].toLowerCase().replace(/\s/g,'');
const ex=examOf(c);let rest=ex?c.replace(ex[0],' '):c;
rest=rest.replace(/[:=]/g,' ').replace(/\s[-–]\s/g,' ').replace(/\bnilai\b/gi,' ');
if(ex&&!rest.trim()){cur=norm(ex);return}
if(ex)cur=norm(ex);
const examId=ex?norm(ex):cur;
const sm=rest.match(/(?:^|\s)(100|\d{1,2})(?=\s|$)/);
if(!examId||!sm){replies.push(`❌ "${c}": Format tidak dikenali. (Cth: Budi UH1 85)`);return}
const r=findStudent(rest.replace(sm[0],' ').replace(/\s+/g,' '));
if(r.err){replies.push('❌ '+r.err);return}
updates.push({id:r.s.id,name:r.s.name,ex:examId,score:sm[1]})});
return{updates,removes,replies}};

const handleSend=e=>{
e.preventDefault();const t=text.trim();if(!t)return;
const {updates,removes,replies}=process(t);setText('');
setMessages(p=>[...p,{id:Date.now(),text:t,sender:'user',time:tm()}]);
setTimeout(()=>{
if(updates.length||removes.length)setStudents(p=>p.map(s=>{const n={...s};
updates.forEach(u=>{if(u.id===s.id)n[u.ex]=u.score});removes.forEach(u=>{if(u.id===s.id)n[u.ex]=''});return n}));
const out=[];
if(updates.length)out.push('✅ Berhasil dicatat:\n'+updates.map(u=>`• ${u.name} (${u.ex.toUpperCase()} = ${u.score})`).join('\n'));
if(removes.length)out.push('🗑️ Dihapus:\n'+removes.map(u=>`• ${u.name} (${u.ex.toUpperCase()})`).join('\n'));
out.push(...replies);
setMessages(p=>[...p,{id:Date.now()+1,text:out.join('\n\n'),sender:'bot',time:tm()}])},300)};

const stamp=()=>new Date().toISOString().slice(0,10);
const avgTxt=st=>{const a=avg(st);return a===null?'':fmt(a)};
const exportCSV=()=>{setMenu(false);
const header=['NO','NAMA',...EXAMS.map(e=>e.label.toUpperCase()),'RATA-RATA'].join(',')+'\n';
const rows=students.map((st,i)=>{const r=[`"${i+1}"`,`"${st.name.replace(/"/g,'""')}"`];EXAMS.forEach(e=>r.push(`"${st[e.id]||''}"`));r.push(`"${avgTxt(st)}"`);return r.join(',')}).join('\n');
dl(header+rows,`Nilai_CATAT_SMART_${stamp()}.csv`,'text/csv;charset=utf-8;')};
const exportExcel=async()=>{setMenu(false);
if(!window.ExcelJS){alert('Library Excel belum termuat (butuh internet sekali). Gunakan Export CSV.');return}
const N=EXAMS.length+3,L=c=>String.fromCharCode(64+c);
const wb=new ExcelJS.Workbook();const ws=wb.addWorksheet('Nilai');
ws.columns=Array.from({length:N},(_,i)=>({width:i===0?6:i===1?28:i===N-1?14:17}));
const fill=c=>({type:'pattern',pattern:'solid',fgColor:{argb:c}});
const thin={style:'thin',color:{argb:'FFCBD5E1'}};const border={top:thin,left:thin,bottom:thin,right:thin};
const dt=new Date().toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric'});
ws.mergeCells(1,1,1,N);const t=ws.getCell(1,1);t.value='REKAP NILAI UJIAN';
t.font={bold:true,size:18,color:{argb:'FFFFFFFF'}};t.fill=fill('FF0F766E');t.alignment={horizontal:'center',vertical:'middle'};ws.getRow(1).height=34;
[['Kelas',info.kelas],['Mata Pelajaran',info.mapel],['Semester / Tahun Ajaran',info.semester],['Tanggal Cetak',dt],['Jumlah Murid',students.length]].forEach(([k,v],i)=>{
const r=i+2;ws.mergeCells(r,1,r,2);ws.mergeCells(r,3,r,N);
const kc=ws.getCell(r,1),vc=ws.getCell(r,3);kc.value=k;vc.value=': '+(v===''||v===undefined?'-':v);
kc.font={bold:true,color:{argb:'FF0F766E'}};kc.fill=fill('FFCCFBF1');vc.fill=fill('FFF0FDFA');vc.font={bold:true,color:{argb:'FF134E4A'}};
kc.alignment=vc.alignment={vertical:'middle'};ws.getRow(r).height=20});
const HR=8;ws.getRow(7).height=8;
const colors=EXAMS.map(e=>e.id==='uts'?['FFF59E0B','FFFEF3C7']:e.id==='uas'?['FF8B5CF6','FFEDE9FE']:['FF3B82F6','FFDBEAFE']);
const heads=['NO','NAMA',...EXAMS.map(e=>e.label.toUpperCase()),'RATA-RATA'];
const hr=ws.getRow(HR);hr.height=40;
heads.forEach((h,i)=>{const c=hr.getCell(i+1);c.value=h;
const bg=i<2?'FF0F766E':i===N-1?'FF059669':colors[i-2][0];
c.font={bold:true,color:{argb:'FFFFFFFF'},size:11};c.fill=fill(bg);c.alignment={horizontal:'center',vertical:'middle',wrapText:true};c.border=border});
students.forEach((st,i)=>{
const rn=HR+1+i,r=ws.getRow(rn);r.height=22;
r.getCell(1).value=i+1;r.getCell(2).value=st.name;
EXAMS.forEach((e,j)=>r.getCell(j+3).value=st[e.id]===''?null:Number(st[e.id]));
const rng=`C${rn}:${L(N-1)}${rn}`,a=avg(st);
r.getCell(N).value={formula:`IF(COUNT(${rng})=0,"",ROUND(AVERAGE(${rng}),1))`,result:a===null?'':Math.round(a*10)/10};
for(let n=1;n<=N;n++){const c=r.getCell(n);c.border=border;c.alignment={horizontal:n===2?'left':'center',vertical:'middle'};
const zebra=i%2===1;
if(n<=2)c.fill=fill(zebra?'FFF1F5F9':'FFFFFFFF');
else if(n===N)c.fill=fill('FFD1FAE5');
else c.fill=fill(zebra?colors[n-3][1]:'FFFFFFFF');
if(n===2)c.font={bold:true,color:{argb:'FF1E293B'}};
if(n>2){const v=n===N?a:c.value;
c.font={bold:true,color:{argb:v===null||v===''?'FF94A3B8':v<60?'FFDC2626':n===N?'FF047857':'FF1E3A8A'}}}}});
const sr=HR+students.length+1,r=ws.getRow(sr);r.height=26;
ws.mergeCells(sr,1,sr,2);r.getCell(1).value='RATA-RATA KELAS';
for(let n=3;n<=N;n++){const cl=L(n),rg=`${cl}${HR+1}:${cl}${HR+students.length}`;
const vals=students.map(st=>n===N?avg(st):(st[EXAMS[n-3].id]===''?null:+st[EXAMS[n-3].id])).filter(x=>x!==null);
r.getCell(n).value={formula:`IF(COUNT(${rg})=0,"",ROUND(AVERAGE(${rg}),1))`,result:vals.length?Math.round(vals.reduce((a,b)=>a+b,0)/vals.length*10)/10:''};r.getCell(n).numFmt='0.0'}
for(let n=1;n<=N;n++){const c=r.getCell(n);c.font={bold:true,color:{argb:'FFFFFFFF'}};c.fill=fill(n===N?'FF059669':'FF0F766E');c.alignment={horizontal:'center',vertical:'middle'};c.border=border}
ws.views=[{state:'frozen',ySplit:HR,xSplit:2}];
ws.pageSetup={orientation:'landscape',fitToPage:true,fitToWidth:1,fitToHeight:0};
const buf=await wb.xlsx.writeBuffer();
dl(buf,`Nilai_${(info.kelas||'Kelas').replace(/[^\w-]+/g,'_')}_${stamp()}.xlsx`,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')};
const dl=async(c,name,type)=>{try{if(Capacitor.isNativePlatform()){let bytes;if(typeof c==='string'){bytes=new TextEncoder().encode(c)}else if(c instanceof ArrayBuffer){bytes=new Uint8Array(c)}else if(ArrayBuffer.isView(c)){bytes=new Uint8Array(c.buffer,c.byteOffset,c.byteLength)}else{bytes=new Uint8Array(await new Blob([c]).arrayBuffer())}let binary='';const CHUNK=0x8000;for(let i=0;i<bytes.length;i+=CHUNK)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+CHUNK,bytes.length)));const base64=btoa(binary);await NativeFile.saveToDownloads({fileName:name,mimeType:type,base64});alert('Berhasil disimpan ke folder Download.\n'+name);return}const u=URL.createObjectURL(new Blob([c],{type}));const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();document.body.removeChild(a);setTimeout(()=>URL.revokeObjectURL(u),500)}catch(e){alert('Gagal menyimpan file: '+(e?.message||e))}};
const backup=()=>{setMenu(false);dl(JSON.stringify({students,messages,hasSetup,info,v:2}),`Backup_CATAT_SMART_${new Date().toISOString().slice(0,10)}.json`,'application/json')};
const importFile=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();
r.onload=()=>{try{const d=JSON.parse(r.result);if(!Array.isArray(d.students))throw 0;
if(!confirm('Data saat ini akan diganti dengan isi backup. Lanjutkan?'))return;
setStudents(d.students);setMessages(d.messages||[]);setInfo(d.info||{kelas:'',mapel:'',semester:''});setHasSetup(true)}catch(x){alert('File backup tidak valid.')}};
r.readAsText(f);e.target.value='';setMenu(false)};
const reset=()=>{setMenu(false);if(confirm('Yakin reset? Semua nama murid dan nilai akan terhapus permanen!')){try{localStorage.removeItem(KEY)}catch(e){}setStudents([]);setMessages([]);setHasSetup(false);setNamesInput('')}};

const addStudents=()=>{const names=addNames.split('\n').map(n=>n.trim()).filter(Boolean);if(!names.length)return;
setStudents(p=>[...p,...mkStudents(names,p.length)]);setAddNames('');setShowAdd(false);
setMessages(p=>[...p,{id:Date.now(),text:`➕ ${names.length} murid ditambahkan.`,sender:'bot',time:tm()}])};
const saveEdit=()=>{const sc={};
for(const e of EXAMS){const v=String(editing[e.id]??'').trim();if(v!==''&&(isNaN(v)||+v<0||+v>100)){alert(`Nilai ${e.short} harus 0–100`);return}sc[e.id]=v}
if(!editing.name.trim()){alert('Nama tidak boleh kosong');return}
setStudents(p=>p.map(s=>s.id===editing.id?{...s,...sc,name:editing.name.trim()}:s));setEditing(null)};
const delStudent=()=>{if(confirm(`Hapus ${editing.name} dari daftar?`)){setStudents(p=>p.filter(s=>s.id!==editing.id));setEditing(null)}};

const savePin=()=>{if(!pinForm.p1&&pin){try{localStorage.removeItem(PIN_KEY)}catch(e){}setPin(null);setShowPin(false);return}
if(!/^\d{4}$/.test(pinForm.p1)){alert('PIN harus 4 angka');return}
if(pinForm.p1!==pinForm.p2){alert('Konfirmasi PIN tidak sama');return}
try{localStorage.setItem(PIN_KEY,pinForm.p1)}catch(e){}setPin(pinForm.p1);setPinForm({p1:'',p2:''});setShowPin(false)};
useEffect(()=>{if(pinIn.length===4){if(pinIn===pin){setLocked(false);setPinErr('')}else setPinErr('PIN salah');setPinIn('')}},[pinIn]);

const stats=useMemo(()=>{
const per=EXAMS.map(e=>{const v=students.map(s=>parseFloat(s[e.id])).filter(n=>!isNaN(n));
return{...e,n:v.length,avg:v.length?v.reduce((a,b)=>a+b,0)/v.length:null,max:v.length?Math.max(...v):null,min:v.length?Math.min(...v):null}});
const rank=students.map(s=>({s,a:avg(s)})).filter(x=>x.a!==null).sort((a,b)=>b.a-a.a);
const filled=students.reduce((c,s)=>c+EXAMS.filter(e=>s[e.id]!=='').length,0);
return{per,rank,filled,total:students.length*EXAMS.length}},[students]);
const missing=useMemo(()=>students.filter(s=>EXAMS.some(e=>s[e.id]==='')).length,[students]);


if(!ready)return null;

if(locked&&pin)return(
<Frame dark={dark}><div className="w-full max-w-md bg-white dark:bg-gray-900 dark:text-gray-100 sm:rounded-3xl flex flex-col items-center justify-center p-6 text-center">
<div className="w-16 h-16 bg-brand-light/20 rounded-2xl flex items-center justify-center text-3xl mb-4">🔒</div>
<h2 className="font-bold text-lg mb-1">CATAT SMART Terkunci</h2><p className="text-sm text-gray-500 mb-4">Masukkan PIN 4 angka</p>
<div className="flex gap-3 mb-2">{[0,1,2,3].map(i=><div key={i} className={`w-4 h-4 rounded-full border-2 border-brand-light ${pinIn.length>i?'bg-brand-light':''}`}/>)}</div>
<p className="text-red-500 text-xs h-4 mb-3">{pinErr}</p>
<div className="grid grid-cols-3 gap-3 w-64">{[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map((k,i)=>k===''?<div key={i}/>:
<button key={i} onClick={()=>k==='⌫'?setPinIn(p=>p.slice(0,-1)):setPinIn(p=>p.length<4?p+k:p)} className="h-14 rounded-full bg-gray-100 dark:bg-gray-800 text-xl font-medium active:scale-95">{k}</button>)}</div>
</div></Frame>);

if(!hasSetup)return(
<Frame dark={dark}><div className="w-full max-w-md bg-chat-bgLight dark:bg-chat-bgDark sm:rounded-3xl overflow-y-auto flex items-center justify-center p-4">
<div className="bg-white dark:bg-gray-800 dark:text-gray-100 p-6 rounded-3xl shadow-xl w-full text-center setup-card">
<img src="icon-192.png" className="w-20 h-20 rounded-2xl mx-auto mb-4 shadow-lg rise" style={{'--i':0}} alt=""/>
<h1 className="text-2xl font-bold mb-2 rise" style={{'--i':1}}>Selamat Datang di<br/><span className="text-brand-light">CATAT SMART</span></h1>
<p className="text-sm text-gray-500 dark:text-gray-400 mb-5 rise" style={{'--i':2}}>Salin daftar nama murid dari Excel atau ketik satu per satu (tiap baris 1 nama).</p>
<textarea style={{'--i':3}} className={inputCls+" h-44 mb-4 resize-none rise"} placeholder={"Contoh:\nAndi Susanto\nBudi Kurniawan\nCitra Lestari"} value={namesInput} onChange={e=>setNamesInput(e.target.value)}/>
<button onClick={handleSetup} className={btnCls+" py-3 font-bold rise"} style={{'--i':4}}>Mulai Aplikasi</button></div></div></Frame>);

const tabBtn=(id,label,icon)=>(<button onClick={()=>setTab(id)} className={`flex-1 py-2 flex flex-col items-center gap-1 rounded-xl transition-colors ${tab===id?'text-brand-light dark:text-emerald-400':'text-gray-400'}`}><span className="text-lg leading-none">{icon}</span>{label}</button>);
const menuItem=(label,fn,extra='')=>(<button onClick={fn} className={`w-full text-left px-4 py-3 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 border-t first:border-t-0 border-gray-100 dark:border-gray-700 ${extra}`}>{label}</button>);
const pane=id=>`absolute inset-0 flex flex-col transition-transform duration-300 ${tab===id?'translate-x-0 screen-in':'pointer-events-none '+(['chat','nilai','rekap'].indexOf(id)<['chat','nilai','rekap'].indexOf(tab)?'-translate-x-full':'translate-x-full')}`;

return(
<Frame dark={dark}><div className="w-full max-w-md bg-white dark:bg-gray-900 dark:text-gray-100 shadow-2xl sm:rounded-3xl overflow-hidden flex flex-col relative">
<header className="bg-brand-light dark:bg-brand-dark text-white p-4 shadow-md z-10 flex justify-between items-center">
<div className="flex items-center gap-3">
<img src="icon-192.png" className="w-10 h-10 rounded-xl" alt=""/>
<div className="flex flex-col"><span className="text-lg font-bold leading-tight">CATAT SMART</span><span className="text-[10px] opacity-90 tracking-widest">ASISTEN NILAI</span></div></div>
<div className="flex items-center gap-2">
<div title="Tersimpan di HP ini" className="w-3 h-3 rounded-full bg-green-400 shadow-[0_0_8px_#4ade80]"/>
<button onClick={()=>setDark(!dark)} className="p-2 rounded-full hover:bg-white/10" aria-label="Mode gelap">{dark?'☀️':'🌙'}</button>
<div className="relative" ref={menuRef}>
<button onClick={()=>setMenu(v=>!v)} className="p-2 rounded-full hover:bg-white/10 font-bold" aria-label="Menu">⋮</button>
{menu&&<div className="absolute right-0 top-12 w-60 bg-white dark:bg-gray-800 rounded-xl shadow-2xl overflow-hidden z-50 text-gray-800 dark:text-gray-100 border border-gray-100 dark:border-gray-700">
{menuItem('🏫 Info Kelas (untuk laporan)',()=>{setInfoForm({kelas:info.kelas||'',mapel:info.mapel||'',semester:info.semester||''});setShowInfo(true);setMenu(false)})}
{menuItem('➕ Tambah Murid',()=>{setShowAdd(true);setMenu(false)})}
{menuItem('📊 Export Excel (rapi, .xlsx)',exportExcel)}
{menuItem('📄 Export CSV',exportCSV)}
{menuItem('💾 Backup Data',backup)}
{menuItem('📂 Restore dari Backup',()=>fileRef.current?.click())}
{menuItem(pin?'🔒 Ubah / Hapus PIN':'🔒 Atur PIN Keamanan',()=>{setShowPin(true);setMenu(false)})}
{menuItem('🗑️ Reset Data',reset,'text-red-600 dark:text-red-400')}</div>}
<input type="file" accept="application/json" ref={fileRef} onChange={importFile} className="hidden"/></div></div></header>

<div className="flex-1 relative overflow-hidden bg-chat-bgLight dark:bg-chat-bgDark">
<div className={pane('chat')}>
<div className="flex-1 overflow-y-auto p-4 space-y-4 hide-scrollbar">
{messages.map((m,i)=><div key={m.id||i} className={`flex ${m.sender==='user'?'justify-end':'justify-start'}`}>
<div className={`max-w-[80%] rounded-2xl p-3 shadow-sm whitespace-pre-wrap text-sm ${m.sender==='user'?'bg-chat-userLight dark:bg-chat-userDark text-black dark:text-gray-100 rounded-tr-sm':'bg-chat-botLight dark:bg-chat-botDark text-black dark:text-gray-100 rounded-tl-sm'}`}>{m.text}<div className="text-[10px] opacity-60 text-right mt-1">{m.time}</div></div></div>)}
<div ref={endRef}/></div>
<form onSubmit={handleSend} className="p-3 bg-gray-100 dark:bg-gray-800 flex gap-2 items-end">
<textarea rows={Math.min(5,text.split('\n').length)} value={text} onChange={e=>setText(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&!e.shiftKey&&window.matchMedia('(hover:hover)').matches){handleSend(e)}}} placeholder={"Satu murid: Andi uh1 85\nSekelas: ketik UH1, lalu tiap baris 'Nama nilai'"} className="flex-1 resize-none bg-white dark:bg-gray-700 dark:text-gray-100 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-light text-sm hide-scrollbar"/>
<button type="submit" disabled={!text.trim()} className="bg-brand-light text-white rounded-full w-12 h-12 flex items-center justify-center disabled:opacity-50 active:scale-95">➤</button></form></div>

<div className={pane('nilai')+' bg-gray-50 dark:bg-gray-900'}>
<div className="p-3 flex justify-between items-center border-b border-gray-200 dark:border-gray-800 text-sm">
<b>{students.length} Murid</b><span className="text-xs text-gray-500">Ketuk baris untuk edit</span></div>
<div className="flex-1 overflow-auto hide-scrollbar">
<table className="min-w-full text-xs"><thead className="bg-gray-100 dark:bg-gray-800 sticky top-0 z-10"><tr>
<th className="px-2 py-2 text-left sticky left-0 bg-gray-100 dark:bg-gray-800">NAMA</th>
{EXAMS.map(e=><th key={e.id} className="px-2 py-2 text-center">{e.short}</th>)}<th className="px-2 py-2 text-center text-brand-light">AVG</th></tr></thead>
<tbody>{students.map((s,i)=><tr key={s.id} onClick={()=>setEditing({...s})} className="border-t border-gray-100 dark:border-gray-800 active:bg-brand-light/10 cursor-pointer">
<td className="px-2 py-2 whitespace-nowrap font-semibold sticky left-0 bg-gray-50 dark:bg-gray-900">{i+1}. {s.name}</td>
{EXAMS.map(e=><td key={e.id} className={`px-2 py-2 text-center font-bold ${s[e.id]!==''?(+s[e.id]<60?'text-red-500':'text-brand-light'):'text-gray-300 dark:text-gray-600'}`}>{s[e.id]!==''?s[e.id]:'-'}</td>)}
<td className="px-2 py-2 text-center font-bold">{fmt(avg(s))}</td></tr>)}</tbody></table></div></div>

<div className={pane('rekap')+' bg-gray-50 dark:bg-gray-900 overflow-y-auto hide-scrollbar p-4 space-y-4'}>
<div className="grid grid-cols-2 gap-3">
<div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Nilai terisi</div><div className="text-xl font-bold text-brand-light">{stats.filled}<span className="text-xs text-gray-400">/{stats.total}</span></div></div>
<div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Murid belum lengkap</div><div className="text-xl font-bold text-amber-500">{missing}</div></div></div>
<div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><h3 className="font-bold text-sm mb-2">Rata-rata per Ujian</h3>
{stats.per.map(p=><div key={p.id} className="mb-2"><div className="flex justify-between text-xs mb-1"><span>{p.short} <span className="text-gray-400">({p.n} nilai)</span></span><span className="font-bold">{fmt(p.avg)}{p.n?<span className="text-gray-400 font-normal"> · {p.min}–{p.max}</span>:''}</span></div>
<div className="h-2 rounded-full bg-gray-200 dark:bg-gray-700"><div className="h-2 rounded-full bg-brand-light" style={{width:`${p.avg||0}%`}}/></div></div>)}</div>
<div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><h3 className="font-bold text-sm mb-2">Peringkat Rata-rata</h3>
{stats.rank.length?stats.rank.map((r,i)=><div key={r.s.id} className="flex justify-between text-sm py-1.5 border-t first:border-t-0 border-gray-100 dark:border-gray-700"><span>{i<3?['🥇','🥈','🥉'][i]:i+1+'.'} {r.s.name}</span><b>{fmt(r.a)}</b></div>):<p className="text-xs text-gray-400">Belum ada nilai.</p>}</div></div>
</div>

<div className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 flex justify-around p-2 text-xs font-medium z-10">
{tabBtn('chat','Pencatat','💬')}{tabBtn('nilai','Nilai','📋')}{tabBtn('rekap','Rekap','📈')}</div>

{editing&&<ModalWrapper title="Edit Murid" onClose={()=>setEditing(null)}>
<input className={inputCls} value={editing.name} onChange={e=>setEditing({...editing,name:e.target.value})}/>
<div className="grid grid-cols-2 gap-2">{EXAMS.map(e=><label key={e.id} className="text-xs">{e.short}<input type="number" inputMode="numeric" min="0" max="100" className={inputCls+' mt-1'} value={editing[e.id]??''} onChange={ev=>setEditing({...editing,[e.id]:ev.target.value})}/></label>)}</div>
<button onClick={saveEdit} className={btnCls}>Simpan Perubahan</button>
<button onClick={delStudent} className="w-full text-red-500 text-sm py-2">Hapus murid ini</button></ModalWrapper>}
{showInfo&&<ModalWrapper title="Info Kelas" onClose={()=>setShowInfo(false)}>
<p className="text-xs text-gray-500">Muncul di bagian atas file Excel.</p>
<input className={inputCls} placeholder="Kelas (cth: 8A)" value={infoForm.kelas} onChange={e=>setInfoForm({...infoForm,kelas:e.target.value})}/>
<input className={inputCls} placeholder="Mata pelajaran (cth: Matematika)" value={infoForm.mapel} onChange={e=>setInfoForm({...infoForm,mapel:e.target.value})}/>
<input className={inputCls} placeholder="Semester / Tahun ajaran (cth: Ganjil 2026/2027)" value={infoForm.semester} onChange={e=>setInfoForm({...infoForm,semester:e.target.value})}/>
<button onClick={()=>{setInfo(infoForm);setShowInfo(false)}} className={btnCls}>Simpan</button></ModalWrapper>}
{showAdd&&<ModalWrapper title="Tambah Murid" onClose={()=>setShowAdd(false)}>
<textarea className={inputCls+' h-32 resize-none'} placeholder={"Satu nama per baris"} value={addNames} onChange={e=>setAddNames(e.target.value)}/>
<button onClick={addStudents} className={btnCls}>Tambahkan</button></ModalWrapper>}
{showPin&&<ModalWrapper title={pin?'Ubah / Hapus PIN':'Atur PIN'} onClose={()=>setShowPin(false)}>
<input type="password" inputMode="numeric" maxLength={4} placeholder={pin?'PIN baru (kosongkan untuk hapus PIN)':'PIN 4 angka'} className={inputCls} value={pinForm.p1} onChange={e=>setPinForm({...pinForm,p1:e.target.value.replace(/\D/g,'')})}/>
{(pinForm.p1||!pin)&&<input type="password" inputMode="numeric" maxLength={4} placeholder="Ulangi PIN" className={inputCls} value={pinForm.p2} onChange={e=>setPinForm({...pinForm,p2:e.target.value.replace(/\D/g,'')})}/>}
<button onClick={savePin} className={btnCls}>Simpan</button></ModalWrapper>}
</div></Frame>);}

