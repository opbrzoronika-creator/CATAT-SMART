package com.nawmanusia.catatsmart;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

@CapacitorPlugin(name="NativeFile")
public class NativeFilePlugin extends Plugin {
 @PluginMethod
 public void saveToDownloads(PluginCall call){
  String name=call.getString("fileName","CATAT_SMART_file"); String mime=call.getString("mimeType","application/octet-stream"); String b64=call.getString("base64","");
  if(b64.isEmpty()){call.reject("Empty file data");return;}
  try{byte[] data=Base64.decode(b64,Base64.DEFAULT);
   if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q){
    ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,mime); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CATAT SMART"); v.put(MediaStore.Downloads.IS_PENDING,1);
    ContentResolver r=getContext().getContentResolver(); Uri uri=r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(uri==null)throw new Exception("Could not create Download entry");
    try(OutputStream os=r.openOutputStream(uri)){if(os==null)throw new Exception("Could not open Download entry"); os.write(data);os.flush();}
    v.clear();v.put(MediaStore.Downloads.IS_PENDING,0);r.update(uri,v,null,null);
   }else{File dir=Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS+"/CATAT SMART"); if(!dir.exists()&&!dir.mkdirs())throw new Exception("Could not create Downloads folder"); try(FileOutputStream os=new FileOutputStream(new File(dir,name))){os.write(data);}}
   call.resolve();
  }catch(Exception e){call.reject("Could not save file: "+e.getMessage());}
 }
}
