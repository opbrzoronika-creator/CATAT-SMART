import React,{useState,useEffect,useMemo,useRef} from 'react';
import * as ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import { Capacitor, registerPlugin } from '@capacitor/core';
import './index.css';

const NativeFile=registerPlugin('NativeFile');
window.ExcelJS=ExcelJS;

const KEY='catat_smart_data_v2',PIN_KEY='catat_smart_pin_v2',DARK_KEY='catat_smart_dark_v2';
const ASSESSMENTS=[
  {id:'tugas1',label:'Tugas 1',short:'T1',group:'Tugas'},
  {id:'tugas2',label:'Tugas 2',short:'T2',group:'Tugas'},
  {id:'uh1',label:'Ulangan Harian 1',short:'UH1',group:'Ulangan'},
  {id:'uh2',label:'Ulangan Harian 2',short:'UH2',group:'Ulangan'},
  {id:'uh3',label:'Ulangan Harian 3',short:'UH3',group:'Ulangan'},
  {id:'uh4',label:'Ulangan Harian 4',short:'UH4',group:'Ulangan'},
  {id:'uh5',label:'Ulangan Harian 5',short:'UH5',group:'Ulangan'},
  {id:'uh6',label:'Ulangan Harian 6',short:'UH6',group:'Ulangan'},
  {id:'uts',label:'Ujian Tengah Semester',short:'UTS',group:'UTS'},
  {id:'uas',label:'Ujian Akhir Semester',short:'UAS',group:'UAS'},
  {id:'praktik',label:'Praktik',short:'PRK',group:'Praktik'}
];
const OLD_ASSESSMENTS=[
  {id:'uh1',label:'Ulangan Harian 1',short:'UH1'},{id:'uh2',label:'Ulangan Harian 2',short:'UH2'},
  {id:'uh3',label:'Ulangan Harian 3',short:'UH3'},{id:'uts',label:'Ujian Tengah Semester',short:'UTS'},
  {id:'uh4',label:'Ulangan Harian 4',short:'UH4'},{id:'uh5',label:'Ulangan Harian 5',short:'UH5'},
  {id:'uh6',label:'Ulangan Harian 6',short:'UH6'},{id:'uas',label:'Ujian Akhir Semester',short:'UAS'}
];
const store={load(){try{return JSON.parse(localStorage.getItem(KEY))}catch(e){return null}},save(d){try{localStorage.setItem(KEY,JSON.stringify(d))}catch(e){}}};
const uid=p=>`${p}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`;
const average=s=>{const v=ASSESSMENTS.map(e=>parseFloat(s[e.id])).filter(n=>!isNaN(n));return v.length?v.reduce((a,b)=>a+b,0)/v.length:null};
const fmt=n=>n===null||n===undefined||Number.isNaN(n)?'-':(Math.round(n*10)/10).toString();
const tm=()=>new Date().toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit'});
const today=()=>new Date().toISOString().slice(0,10);
const emptyStudent=(name,number='')=>{const s={id:uid('stu'),name,nis:'',nisn:'',number};ASSESSMENTS.forEach(e=>s[e.id]='');return s};
const newSubject=(data={})=>({id:data.id||uid('sub'),name:data.name||''});
const emptyGrades=()=>Object.fromEntries(ASSESSMENTS.map(e=>[e.id,'']));
const newClass=(data={})=>({id:data.id||uid('cls'),name:data.name||'',level:data.level||'',academicYear:data.academicYear||'',semester:data.semester||'',homeroom:data.homeroom||'',subjects:Array.isArray(data.subjects)?data.subjects.map(x=>newSubject(x)):[],activeSubjectId:data.activeSubjectId||null,students:Array.isArray(data.students)?data.students:[],messages:Array.isArray(data.messages)?data.messages:[],messagesBySubject:data.messagesBySubject&&typeof data.messagesBySubject==='object'?data.messagesBySubject:{}});

function migrate(raw){
  if(!raw)return null;
  if(Array.isArray(raw.classes)){
    const classes=raw.classes.map(c=>{
      const oldSubject=(c.subject||'').trim();
      let subjects=Array.isArray(c.subjects)?c.subjects.map(x=>newSubject(x)).filter(x=>x.name):[];
      if(!subjects.length && oldSubject) subjects=[newSubject({name:oldSubject})];
      const activeSubjectId=c.activeSubjectId&&subjects.some(x=>x.id===c.activeSubjectId)?c.activeSubjectId:(subjects[0]?.id||null);
      const migratedStudents=(Array.isArray(c.students)?c.students:[]).map((st,i)=>{
        const n={...emptyStudent(st.name||'',st.number||i+1),...st,id:st.id||uid('stu')};
        if(!n.grades || typeof n.grades!=='object'){
          n.grades={};
          if(activeSubjectId)n.grades[activeSubjectId]=Object.fromEntries(ASSESSMENTS.map(e=>[e.id,st[e.id]??'']));
        }
        return n;
      });
      const oldMessages=Array.isArray(c.messages)?c.messages:[]; const messagesBySubject=(c.messagesBySubject&&typeof c.messagesBySubject==='object')?c.messagesBySubject:(activeSubjectId&&oldMessages.length?{[activeSubjectId]:oldMessages}:{}); return {...newClass({...c,subjects,activeSubjectId}),...c,subjects,activeSubjectId,students:migratedStudents,messages:oldMessages,messagesBySubject};
    });
    const activeClassId=classes.some(c=>c.id===raw.activeClassId)?raw.activeClassId:(classes[0]?.id||null);
    return {...raw,schema:4,classes,activeClassId};
  }
  if(Array.isArray(raw.students)){
    const info=raw.info||{};
    const subjectName=(info.mapel||'').trim();
    const sub=subjectName?newSubject({name:subjectName}):null;
    const students=raw.students.map((st,i)=>{
      const n=emptyStudent(st.name||'',i+1); n.id=st.id||n.id; n.nis=st.nis||''; n.nisn=st.nisn||''; n.number=st.number||i+1;
      n.grades={}; if(sub)n.grades[sub.id]=Object.fromEntries(OLD_ASSESSMENTS.map(e=>[e.id,st[e.id]??'']));
      return n;
    });
    const c=newClass({name:info.kelas||'Kelas 1',academicYear:info.tahunAjaran||'',semester:info.semester||'',students,subjects:sub?[sub]:[],activeSubjectId:sub?.id||null});
    return {schema:4,classes:[c],activeClassId:c.id};
  }
  return null;
}

const Modal=({title,onClose,children,wide=false})=>(
  <div className="fixed inset-0 bg-black/50 z-[100] flex items-end sm:items-center justify-center" onClick={onClose}>
    <div className={`bg-white dark:bg-gray-800 dark:text-gray-100 rounded-t-2xl sm:rounded-2xl w-full ${wide?'sm:max-w-lg':'sm:max-w-md'} max-h-[90vh] overflow-y-auto modal-rise`} onClick={e=>e.stopPropagation()}>
      <div className="flex justify-between items-center p-4 border-b border-gray-100 dark:border-gray-700 sticky top-0 bg-white dark:bg-gray-800 z-10"><h3 className="font-bold">{title}</h3><button onClick={onClose} className="text-xl px-2">✕</button></div>
      <div className="p-4 space-y-3">{children}</div>
    </div>
  </div>
);
const inputCls='w-full bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-brand-light';
const btnCls='w-full bg-brand-light text-white rounded-lg py-2.5 text-sm font-medium active:scale-[.99] transition-transform';
const Frame=({dark,children})=><div className={dark?'dark':''}><div className="app-viewport no-select-ui w-full h-[100dvh] min-h-0 flex justify-center bg-gray-200 dark:bg-black sm:p-4">{children}</div></div>;

const SetupForm=({onCancel,onSave})=>{
 const [f,setF]=useState({name:'',level:'',subject:'',academicYear:'',semester:'',homeroom:''});
 const set=(k,v)=>setF(x=>({...x,[k]:v}));
 return <div className="space-y-3">
  <input className={inputCls} placeholder="Nama kelas (contoh: 7A)" value={f.name} onChange={e=>set('name',e.target.value)}/>
  <input className={inputCls} placeholder="Jenjang (TK / SD / SMP / SMA)" value={f.level} onChange={e=>set('level',e.target.value)}/>
  <input className={inputCls} placeholder="Tahun ajaran (contoh: 2026/2027)" value={f.academicYear} onChange={e=>set('academicYear',e.target.value)}/>
  <input className={inputCls} placeholder="Semester (Ganjil / Genap)" value={f.semester} onChange={e=>set('semester',e.target.value)}/>
  <input className={inputCls} placeholder="Wali kelas" value={f.homeroom} onChange={e=>set('homeroom',e.target.value)}/>
  <button className={btnCls+" mt-3"} onClick={()=>{if(!f.name.trim()){alert('Nama kelas wajib diisi.');return}onSave(f)}}>MASUK KE CATAT SMART</button>
  <button className="w-full text-sm text-gray-500 py-2" onClick={onCancel}>Kembali</button>
 </div>
};

function App(){
 const [ready,setReady]=useState(false),[data,setData]=useState(null),[tab,setTab]=useState('chat'),[showLanding,setShowLanding]=useState(true),[showSetup,setShowSetup]=useState(false);
 const [dark,setDark]=useState(()=>{try{return localStorage.getItem(DARK_KEY)==='1'}catch(e){return false}});
 const [menu,setMenu]=useState(false),[text,setText]=useState(''),[pin,setPin]=useState(()=>{try{return localStorage.getItem(PIN_KEY)}catch(e){return null}}),[locked,setLocked]=useState(()=>{try{return !!localStorage.getItem(PIN_KEY)}catch(e){return false}}),[pinIn,setPinIn]=useState(''),[pinErr,setPinErr]=useState('');
 const [showClass,setShowClass]=useState(false),[classForm,setClassForm]=useState({});
 const [showSubject,setShowSubject]=useState(false),[subjectForm,setSubjectForm]=useState({});
 const [showStudent,setShowStudent]=useState(false),[studentForm,setStudentForm]=useState({});
 const [showBatchStudent,setShowBatchStudent]=useState(false),[batchClassId,setBatchClassId]=useState(''),[batchText,setBatchText]=useState('');
 const [editingStudent,setEditingStudent]=useState(null),[showPin,setShowPin]=useState(false),[pinForm,setPinForm]=useState({p1:'',p2:''});
 const [showRestore,setShowRestore]=useState(false),fileRef=useRef(null),menuRef=useRef(null),endRef=useRef(null);

 useEffect(()=>{const d=migrate(store.load()); if(d)setData(d); setReady(true)},[]);
 useEffect(()=>{if(ready&&data)store.save({...data,schema:4})},[data,ready]);
 useEffect(()=>{try{localStorage.setItem(DARK_KEY,dark?'1':'0')}catch(e){}},[dark]);
 useEffect(()=>{const h=e=>{if(menuRef.current&&!menuRef.current.contains(e.target))setMenu(false)};document.addEventListener('mousedown',h);document.addEventListener('touchstart',h);return()=>{document.removeEventListener('mousedown',h);document.removeEventListener('touchstart',h)}},[]);
 useEffect(()=>{if(pinIn.length===4){if(pinIn===pin){setLocked(false);setPinErr('')}else setPinErr('PIN salah');setPinIn('')}},[pinIn,pin]);

 const activeClass=data?.classes?.find(c=>c.id===data.activeClassId)||data?.classes?.[0];
 const subjects=activeClass?.subjects||[];
 const activeSubject=subjects.find(x=>x.id===activeClass?.activeSubjectId)||subjects[0]||null;
 const activeSubjectId=activeSubject?.id||null;
 const students=activeClass?.students||[];
 const gradeOf=s=>((s?.grades&&activeSubjectId&&s.grades[activeSubjectId])?s.grades[activeSubjectId]:emptyGrades());
 const setClasses=fn=>setData(d=>({...d,classes:fn(d.classes)}));
 const updateActiveClass=(fn)=>setClasses(cs=>cs.map(c=>c.id===activeClass.id?fn(c):c));
 const updateStudent=(studentId,fn)=>updateActiveClass(c=>({...c,students:c.students.map(s=>s.id===studentId?fn(s):s)}));
 const messages=(activeClass?.messagesBySubject&&activeSubjectId)?(activeClass.messagesBySubject[activeSubjectId]||[]):(activeClass?.messages||[]);
 const setMessages=fn=>updateActiveClass(c=>{const all={...(c.messagesBySubject||{})};const prev=all[activeSubjectId]||[];all[activeSubjectId]=typeof fn==='function'?fn(prev):fn;return {...c,messagesBySubject:all}});
 useEffect(()=>{if(messages.length) endRef.current?.scrollIntoView({behavior:'smooth',block:'end'})},[tab,data?.activeClassId,messages.length]);

 const stats=useMemo(()=>{
   const per=ASSESSMENTS.map(e=>{const v=students.map(s=>parseFloat(gradeOf(s)[e.id])).filter(n=>!isNaN(n));return{...e,n:v.length,avg:v.length?v.reduce((a,b)=>a+b,0)/v.length:null,min:v.length?Math.min(...v):null,max:v.length?Math.max(...v):null}});
   const ranked=students.map(s=>({s,a:average(gradeOf(s))})).filter(x=>x.a!==null).sort((a,b)=>b.a-a.a);
   const filled=students.reduce((n,s)=>n+ASSESSMENTS.filter(e=>gradeOf(s)[e.id]!=='').length,0),total=students.length*ASSESSMENTS.length;
   return{per,ranked,filled,total};
 },[students,activeSubjectId]);
 const missing=students.filter(s=>ASSESSMENTS.some(e=>gradeOf(s)[e.id]==='')).length;

 const enterApp=()=>{setShowLanding(false);if(!data)setShowSetup(true)};
 const cancelSetup=()=>{setShowSetup(false);setShowLanding(true)};
 const createInitial=(form)=>{const c=newClass(form);setData({schema:4,classes:[c],activeClassId:c.id});setShowSetup(false);setTab('kelas')};
 if(!ready)return null;
 if(showLanding)return <Frame dark={dark}><div className="w-full max-w-md bg-white dark:bg-gray-900 dark:text-gray-100 sm:rounded-3xl flex flex-col min-h-full items-center justify-center p-7 text-center screen-in"><img src="icon-192.png" className="w-32 h-32 rounded-[30px] shadow-xl mb-5 landing-logo"/><h1 className="text-3xl font-black tracking-tight mb-2">CATAT SMART</h1><p className="text-xs tracking-[.22em] text-brand-light font-semibold mb-3">ASISTEN NILAI</p><p className="text-sm text-gray-500 dark:text-gray-400 leading-6 max-w-xs mb-8">Asisten pencatatan dan pengelolaan nilai untuk TK, SD, SMP, dan SMA.</p><div className="grid grid-cols-3 gap-2 w-full max-w-sm mb-8"><div className="rounded-2xl bg-gray-50 dark:bg-gray-800 p-3 text-xs">📚<br/><b className="text-[11px]">Kelas</b></div><div className="rounded-2xl bg-gray-50 dark:bg-gray-800 p-3 text-xs">👨‍🎓<br/><b className="text-[11px]">Siswa</b></div><div className="rounded-2xl bg-gray-50 dark:bg-gray-800 p-3 text-xs">📊<br/><b className="text-[11px]">Nilai</b></div></div><button onClick={enterApp} className={btnCls+" max-w-sm shadow-lg shadow-brand-light/20"}>MASUK</button><div className="text-[8px] text-gray-400 mt-4">Create by : Naw Manusia</div></div></Frame>;
 if(showSetup)return <Frame dark={dark}><div className="w-full max-w-md bg-white dark:bg-gray-900 dark:text-gray-100 sm:rounded-3xl flex flex-col min-h-full p-6 screen-in"><div className="flex items-center gap-3 mb-7"><img src="icon-192.png" className="w-12 h-12 rounded-2xl"/><div><h2 className="font-bold text-xl">Siapkan Kelas</h2><p className="text-xs text-gray-500">Isi data awal CATAT SMART</p></div></div><SetupForm onCancel={cancelSetup} onSave={createInitial}/></div></Frame>;
 if(locked&&pin)return <Frame dark={dark}><div className="w-full max-w-md bg-white dark:bg-gray-900 dark:text-gray-100 sm:rounded-3xl flex flex-col items-center justify-center p-6 text-center"><div className="w-16 h-16 bg-brand-light/20 rounded-2xl flex items-center justify-center text-3xl mb-4">🔒</div><h2 className="font-bold text-lg mb-1">CATAT SMART Terkunci</h2><p className="text-sm text-gray-500 mb-4">Masukkan PIN 4 angka</p><div className="flex gap-3 mb-2">{[0,1,2,3].map(i=><div key={i} className={`w-4 h-4 rounded-full border-2 border-brand-light ${pinIn.length>i?'bg-brand-light':''}`}/>)}</div><p className="text-red-500 text-xs h-4 mb-3">{pinErr}</p><div className="grid grid-cols-3 gap-3 w-64">{[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map((k,i)=>k===''?<div key={i}/>:<button key={i} onClick={()=>k==='⌫'?setPinIn(p=>p.slice(0,-1)):setPinIn(p=>p.length<4?p+k:p)} className="h-14 rounded-full bg-gray-100 dark:bg-gray-800 text-xl font-medium active:scale-95">{k}</button>)}</div></div></Frame>;

 const ensureMessages=()=>messages.length?messages:[{id:'welcome',sender:'bot',time:tm(),text:`Halo! 👋 Selamat datang di CATAT SMART.\n\nKelas: ${activeClass.name||'-'}\nMata pelajaran: ${activeSubject?.name||'-'}\n${students.length} siswa siap dicatat.\n\nContoh cepat:\n• Andi UH1 85\n• Siti UTS 90\n• UH1: Andi 85, Siti 90`}];
 const findStudent=q=>{const m=students.filter(s=>s.name.toLowerCase().includes(q.trim().toLowerCase()));if(m.length===1)return{s:m[0]};if(m.length>1){const x=m.find(s=>s.name.toLowerCase()===q.trim().toLowerCase());if(x)return{s:x};return{err:`Nama terlalu singkat. Cocok: ${m.map(s=>s.name).join(', ')}`}}return{err:`Murid "${q.trim()}" tidak ditemukan.`}};
 const processCommand=raw=>{const updates=[],replies=[];let current=null;raw.split(/[,;\n]/).forEach(c0=>{let c=c0.trim();if(!c)return;const del=c.match(/^(hapus|delete|del)\s+(.+)$/i);if(del){const ex=del[2].match(/\b(uh\s*[1-6]|uts|uas|tugas\s*[12]|praktik)\b/i);if(!ex){replies.push('❌ Sebutkan penilaian, contoh: hapus Andi UH1');return}const r=findStudent(del[2].replace(ex[0],''));if(r.err){replies.push('❌ '+r.err);return}updates.push({id:r.s.id,ex:ex[0].toLowerCase().replace(/\s/g,''),score:''});return}const ex=c.match(/\b(uh\s*[1-6]|uts|uas|tugas\s*[12]|praktik)\b/i);if(ex)current=ex[0].toLowerCase().replace(/\s/g,'');let rest=ex?c.replace(ex[0],' '):c;rest=rest.replace(/[:=]/g,' ').replace(/\bnilai\b/gi,' ');const score=rest.match(/(?:^|\s)(100|\d{1,2})(?=\s|$)/);if(!score||!current){replies.push(`❌ "${c}": gunakan format Nama UH1 85 atau UH1: Nama 85`);return}const r=findStudent(rest.replace(score[0],' ').replace(/\s+/g,' '));if(r.err){replies.push('❌ '+r.err);return}updates.push({id:r.s.id,ex:current,score:score[1]})});return{updates,replies}};
 const handleSend=e=>{e.preventDefault();const t=text.trim();if(!t)return;if(!activeSubject){setMessages(p=>[...ensureMessages(),{id:uid('msg'),sender:'bot',time:tm(),text:'⚠️ Pilih atau buat mata pelajaran terlebih dahulu.'}]);return}const {updates,replies}=processCommand(t);setText('');setMessages(p=>[...p,...ensureMessages().slice(-1),{id:uid('msg'),sender:'user',time:tm(),text:t}]);setTimeout(()=>{if(updates.length)updateActiveClass(c=>({...c,students:c.students.map(s=>{const n={...s,grades:{...(s.grades||{})}};const g={...(n.grades[activeSubjectId]||emptyGrades())};updates.forEach(u=>{if(u.id===s.id&&ASSESSMENTS.some(a=>a.id===u.ex))g[u.ex]=u.score});n.grades[activeSubjectId]=g;return n})}));const ok=updates.length?`✅ Berhasil dicatat di ${activeSubject.name}:\n${updates.map(u=>`• ${students.find(s=>s.id===u.id)?.name||''} (${u.ex.toUpperCase()} = ${u.score||'dihapus'})`).join('\n')}`:'';setMessages(p=>[...p,{id:uid('msg'),sender:'bot',time:tm(),text:[ok,...replies].filter(Boolean).join('\n\n')||'ℹ️ Tidak ada perubahan.'}])},250)};

 const saveClass=()=>{
   if(!classForm.name?.trim()){alert('Nama kelas wajib diisi.');return}
   const clean={...classForm,name:classForm.name.trim()}; delete clean.subject;
   setData(d=>{
     if(d.classes.some(c=>c.id===clean.id)) return {...d,classes:d.classes.map(c=>c.id===clean.id?{...c,...clean}:c)};
     const c={...newClass(clean),students:[],messages:[],subjects:[]};
     return {...d,classes:[...d.classes,c],activeClassId:c.id};
   });
   setShowClass(false);
 };
 const saveSubject=()=>{
   if(!subjectForm.name?.trim()){alert('Nama mata pelajaran wajib diisi.');return}
   const clean={...subjectForm,name:subjectForm.name.trim()};
   setData(d=>({...d,classes:d.classes.map(c=>{
     if(c.id!==activeClass.id)return c;
     const subs=Array.isArray(c.subjects)?c.subjects:[];
     if(clean.id)return {...c,subjects:subs.map(x=>x.id===clean.id?{...x,...clean}:x),activeSubjectId:clean.id};
     const sub=newSubject(clean); return {...c,subjects:[...subs,sub],activeSubjectId:sub.id};
   })}));
   setShowSubject(false);setSubjectForm({});
 };
 const deleteSubject=(id)=>{if(subjects.length<=1){alert('Kelas harus memiliki minimal satu mata pelajaran.');return}const sub=subjects.find(x=>x.id===id);if(!confirm(`Hapus mata pelajaran "${sub?.name||''}" beserta nilai pada mata pelajaran ini?`))return;setData(d=>({...d,classes:d.classes.map(c=>{if(c.id!==activeClass.id)return c;const rest=c.subjects.filter(x=>x.id!==id);const nextId=rest[0]?.id||null;const students=c.students.map(st=>{const grades={...(st.grades||{})};delete grades[id];return {...st,grades}});return {...c,subjects:rest,activeSubjectId:nextId,students}})}));};
 const deleteClass=()=>{if(data.classes.length===1){alert('Minimal harus ada satu kelas.');return}if(!confirm(`Hapus kelas "${activeClass.name}" beserta seluruh datanya?`))return;const rest=data.classes.filter(c=>c.id!==activeClass.id);setData(d=>({...d,classes:rest,activeClassId:rest[0].id}));setShowClass(false)};
 const saveStudent=()=>{
   if(!studentForm.name?.trim()){alert('Nama siswa wajib diisi.');return}
   const targetId=studentForm.classId||data.activeClassId;
   const s={...emptyStudent(studentForm.name.trim(),studentForm.number||''),...studentForm,name:studentForm.name.trim(),grades:studentForm.grades||{}};
   setData(d=>({...d,classes:d.classes.map(c=>{
     if(c.id!==targetId)return c;
     if(studentForm.id)return {...c,students:c.students.map(x=>x.id===studentForm.id?{...x,...s}:x)};
     return {...c,students:[...c.students,s]};
   }),activeClassId:targetId}));
   setShowStudent(false);
 };
 const saveBatchStudents=()=>{
   const targetId=batchClassId||data.activeClassId;
   const lines=batchText.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);
   if(!lines.length){alert('Masukkan minimal satu siswa.');return}
   const parsed=[];let nextNo=0;
   const target=data.classes.find(c=>c.id===targetId);nextNo=(target?.students||[]).reduce((m,s)=>Math.max(m,parseInt(s.number)||0),0)+1;
   lines.forEach((line,i)=>{
     const parts=line.split(/\s*\|\s*|\s*;\s*|\t/).map(x=>x.trim());
     const name=parts[0]||'';if(!name)return;
     parsed.push(emptyStudent(name,parts[3]||String(nextNo+i)));
     parsed[parsed.length-1].nis=parts[1]||'';parsed[parsed.length-1].nisn=parts[2]||'';
   });
   if(!parsed.length){alert('Data siswa tidak terbaca.');return}
   setData(d=>({...d,activeClassId:targetId,classes:d.classes.map(c=>c.id===targetId?{...c,students:[...(c.students||[]),...parsed]}:c)}));
   setBatchText('');setShowBatchStudent(false);alert(`${parsed.length} siswa berhasil ditambahkan.`);
 };
 const deleteStudent=()=>{if(!editingStudent)return;if(!confirm(`Hapus ${editingStudent.name}?`))return;updateActiveClass(c=>({...c,students:c.students.filter(s=>s.id!==editingStudent.id)}));setEditingStudent(null)};
 const savePin=()=>{if(pinForm.p1===''&&pin){localStorage.removeItem(PIN_KEY);setPin(null);setShowPin(false);return}if(!/^\d{4}$/.test(pinForm.p1)||pinForm.p1!==pinForm.p2){alert('PIN harus 4 angka dan konfirmasi harus sama.');return}localStorage.setItem(PIN_KEY,pinForm.p1);setPin(pinForm.p1);setShowPin(false);setPinForm({p1:'',p2:''})};

 const dl=async(c,name,type)=>{try{if(Capacitor.isNativePlatform()){let bytes;if(typeof c==='string')bytes=new TextEncoder().encode(c);else if(c instanceof ArrayBuffer)bytes=new Uint8Array(c);else if(ArrayBuffer.isView(c))bytes=new Uint8Array(c.buffer,c.byteOffset,c.byteLength);else bytes=new Uint8Array(await new Blob([c]).arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=0x8000)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+0x8000,bytes.length)));await NativeFile.saveToDownloads({fileName:name,mimeType:type,base64:btoa(binary)});alert(`Berhasil disimpan ke folder Download.\n${name}`);return}const u=URL.createObjectURL(new Blob([c],{type}));const a=document.createElement('a');a.href=u;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),500)}catch(e){alert('Gagal menyimpan file: '+(e?.message||e))}};
 const subjectAverage=(student,subjectId)=>{
   const grades=(student?.grades&&student.grades[subjectId])||emptyGrades();
   const vals=ASSESSMENTS.map(a=>parseFloat(grades[a.id])).filter(n=>!isNaN(n));
   return vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null;
 };
 const overallAverage=(student, cls=activeClass)=>{
   const vals=(cls?.subjects||[]).map(sub=>subjectAverage(student,sub.id)).filter(v=>v!==null);
   return vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:null;
 };
 const classSubjectStats=(cls,sub)=>{
   const list=cls.students.map(s=>subjectAverage(s,sub.id)).filter(v=>v!==null);
   return {avg:list.length?list.reduce((a,b)=>a+b,0)/list.length:null,count:list.length,min:list.length?Math.min(...list):null,max:list.length?Math.max(...list):null};
 };
 const classSafeName=cls=>(cls?.name||'Kelas').replace(/[^\w-]+/g,'_');
 const exportClassPDF=(cls=activeClass)=>{
   if(!cls){alert('Kelas belum tersedia.');return}
   const subs=Array.isArray(cls.subjects)?cls.subjects:[];
   if(!subs.length){alert('Kelas ini belum memiliki mata pelajaran.');return}
   try{
     const doc=new jsPDF({orientation:'landscape',unit:'mm',format:'a4'});
     const pageW=297,pageH=210,margin=10,blue=[8,95,155],dark=[20,58,90],border=[205,215,224],zebra=[247,250,253];
     const date=new Date().toLocaleDateString('id-ID');
     const safe=(v,max=34)=>String(v??'-').replace(/\s+/g,' ').trim().slice(0,max)||'-';
     const fitWidths=(base)=>{
       const usable=pageW-margin*2;
       const total=base.reduce((a,b)=>a+b,0);
       if(total<=usable)return base;
       const fixed=[base[0],base[1],base[2]];
       const fixedTotal=fixed.reduce((a,b)=>a+b,0);
       const rest=base.length-fixed.length;
       const restTarget=Math.max(12,(usable-fixedTotal)/Math.max(1,rest));
       return [...fixed,...base.slice(3).map(()=>restTarget)];
     };
     const drawHeader=(title,subtitle)=>{
       doc.setFillColor(...blue);doc.roundedRect(margin,8,pageW-margin*2,17,3,3,'F');
       doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(14);doc.text('CATAT SMART',margin+5,18);
       doc.setFontSize(9);doc.text(title,margin+52,18);
       doc.setFont('helvetica','normal');doc.setFontSize(7);doc.text(subtitle||'',pageW-margin-5,18,{align:'right'});
     };
     const drawMeta=(subName)=>{
       doc.setTextColor(...dark);doc.setFont('helvetica','normal');doc.setFontSize(7.5);
       const y1=31,y2=36;
       doc.text(`Jenjang: ${safe(cls.level)}   Kelas: ${safe(cls.name)}   Mata Pelajaran: ${safe(subName||'REKAP KESELURUHAN',28)}`,margin,y1);
       doc.text(`Wali Kelas: ${safe(cls.homeroom)}   Tahun Ajaran: ${safe(cls.academicYear)}   Semester: ${safe(cls.semester)}   Tanggal: ${date}`,margin,y2);
     };
     const drawTable=(headers,widths,rows,startY,subName)=>{
       const ws=fitWidths(widths),headH=8,rowH=6,minY=44,bottom=pageH-12;
       let y=startY;
       const header=()=>{
         let x=margin;doc.setFillColor(...blue);doc.setDrawColor(...blue);doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(6.6);
         headers.forEach((h,i)=>{doc.rect(x,y,ws[i],headH,'F');const t=safe(h,22);doc.text(t,x+ws[i]/2,y+5.1,{align:'center'});x+=ws[i]});
         y+=headH;
       };
       header();
       rows.forEach((vals,i)=>{
         if(y+rowH>bottom){
           doc.addPage();
           drawHeader(subName==='REKAP KESELURUHAN'?'REKAP KESELURUHAN':'REKAP NILAI',`Kelas ${safe(cls.name)}`);
           drawMeta(subName); y=44; header();
         }
         let x=margin;doc.setFont('helvetica','normal');doc.setFontSize(6.5);doc.setTextColor(35,45,55);
         vals.forEach((v,j)=>{doc.setFillColor(...(i%2?zebra:[255,255,255]));doc.setDrawColor(...border);doc.rect(x,y,ws[j],rowH,'FD');let t=safe(v, j===2?30:18);if(j===2){doc.text(t,x+1.5,y+4.1,{align:'left'})}else{doc.text(t,x+ws[j]/2,y+4.1,{align:'center'})}x+=ws[j]});
         y+=rowH;
       });
       return y;
     };
     const footer=()=>{const total=doc.getNumberOfPages();for(let i=1;i<=total;i++){doc.setPage(i);doc.setTextColor(125,135,145);doc.setFont('helvetica','normal');doc.setFontSize(7);doc.text(`CATAT SMART · ${safe(cls.name,30)} · Halaman ${i}/${total}`,pageW-margin,pageH-5,{align:'right'});}};

     // PAGE 1 — SAME STRUCTURE AS EXCEL SHEET 1
     drawHeader('REKAP KESELURUHAN',`Kelas ${safe(cls.name)}`);
     drawMeta('REKAP KESELURUHAN');
     const overallHeaders=['NO','NIS/NISN','NAMA',...subs.map(s=>safe(s.name,22)),'RATA-RATA'];
     const overallWidths=[9,25,48,...subs.map(()=>22),20];
     const overallRows=cls.students.map((st,i)=>[
       i+1,st.nis||st.nisn||'',st.name,...subs.map(sub=>fmt(subjectAverage(st,sub.id))),fmt(overallAverage(st,cls))
     ]);
     drawTable(overallHeaders,overallWidths,overallRows,42,'REKAP KESELURUHAN');

     // EACH SUBJECT STARTS ON A NEW PAGE, USING THE SAME TABLE STRUCTURE AS EXCEL
     subs.forEach(sub=>{
       doc.addPage();
       drawHeader('REKAP NILAI',`Kelas ${safe(cls.name)} · ${safe(sub.name)}`);
       drawMeta(sub.name);
       const headers=['NO','NIS/NISN','NAMA','NO ABSEN',...ASSESSMENTS.map(a=>a.short),'RATA-RATA'];
       const widths=[9,24,43,13,...ASSESSMENTS.map(()=>16),20];
       const rows=cls.students.map((st,i)=>{
         const g=(st.grades&&st.grades[sub.id])||emptyGrades();
         return [i+1,st.nis||st.nisn||'',st.name,st.number||i+1,...ASSESSMENTS.map(a=>g[a.id]!==''?g[a.id]:'-'),fmt(subjectAverage(st,sub.id))];
       });
       const stat=classSubjectStats(cls,sub);
       doc.setFont('helvetica','bold');doc.setFontSize(7.5);doc.setTextColor(...dark);doc.text(`Rata-rata kelas: ${fmt(stat.avg)}   Nilai terisi: ${stat.count}/${cls.students.length}`,margin,41);
       drawTable(headers,widths,rows,45,sub.name);
     });

     footer();
     dl(doc.output('arraybuffer'),`Rekap_${classSafeName(cls)}_${today()}.pdf`,'application/pdf');
   }catch(e){alert('Gagal membuat PDF kelas: '+(e?.message||e))}
 };
 const exportClassExcel=async(cls=activeClass)=>{
   if(!cls){alert('Kelas belum tersedia.');return}
   const subs=Array.isArray(cls.subjects)?cls.subjects:[];
   if(!subs.length){alert('Kelas ini belum memiliki mata pelajaran.');return}
   try{
     const wb=new ExcelJS.Workbook();
     wb.creator='CATAT SMART';wb.lastModifiedBy='CATAT SMART';wb.created=new Date();wb.modified=new Date();
     wb.properties={title:`Rekap Nilai ${cls.name||'Kelas'}`,subject:'Rekap nilai siswa',company:'CATAT SMART'};
     const C={blue:'FF085F9B',blueDark:'FF064C7C',blueLight:'FFEAF4FB',bluePale:'FFF6FAFD',white:'FFFFFFFF',text:'FF243746',border:'FFD4DEE6',zebra:'FFF7FAFC'};
     const thin={style:'thin',color:{argb:C.border}};
     const medium={style:'medium',color:{argb:C.blue}};
     const borderAll={top:thin,left:thin,bottom:thin,right:thin};
     const date=new Date().toLocaleDateString('id-ID');
     const safeSheet=(name,index)=>{
       let n=String(name||`Mata Pelajaran ${index+1}`).replace(/[\\/?*\[\]:]/g,' ').trim().slice(0,31)||`Mapel ${index+1}`;
       const exists=wb.worksheets.some(x=>x.name===n);if(exists)n=(n.slice(0,27)||'Mapel')+`_${index+1}`;return n;
     };
     const styleTitle=(ws,lastCol,text)=>{
       ws.mergeCells(1,1,1,lastCol);const c=ws.getCell(1,1);c.value=text;c.font={name:'Aptos Display',bold:true,size:18,color:{argb:C.white}};c.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.blue}};c.alignment={horizontal:'center',vertical:'middle'};ws.getRow(1).height=34;
     };
     const styleMeta=(ws,meta,lastCol)=>{
       meta.forEach((m,i)=>{
         const r=3+i;ws.mergeCells(r,2,r,lastCol);const l=ws.getCell(r,1),v=ws.getCell(r,2);l.value=m[0];v.value=m[1]||'-';l.font={name:'Aptos',bold:true,size:10,color:{argb:C.blueDark}};v.font={name:'Aptos',size:10,color:{argb:C.text}};l.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.blueLight}};v.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.bluePale}};l.alignment={vertical:'middle'};v.alignment={vertical:'middle'};l.border={top:thin,left:thin,bottom:thin,right:thin};v.border={top:thin,left:thin,bottom:thin,right:thin};ws.getRow(r).height=21;
       });
     };
     const styleHeader=(ws,row,lastCol)=>{
       for(let i=1;i<=lastCol;i++){const c=ws.getCell(row,i);c.font={name:'Aptos',bold:true,size:10,color:{argb:C.white}};c.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.blueDark}};c.alignment={horizontal:'center',vertical:'middle',wrapText:true};c.border={top:medium,left:thin,bottom:medium,right:thin};}
       ws.getRow(row).height=30;
     };
     const styleRows=(ws,start,end,lastCol,nameCol=3)=>{
       for(let r=start;r<=end;r++){
         ws.getRow(r).height=22;
         for(let c=1;c<=lastCol;c++){const cell=ws.getCell(r,c);cell.font={name:'Aptos',size:10,color:{argb:C.text}};cell.alignment={horizontal:c===nameCol?'left':'center',vertical:'middle',wrapText:c===nameCol};cell.border=borderAll;if((r-start)%2===1)cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.zebra}};}
       }
     };
     const setup=(ws,lastCol,headerRow,freezeCol)=>{
       ws.views=[{state:'frozen',ySplit:headerRow,xSplit:freezeCol}];
       ws.autoFilter={from:{row:headerRow,column:1},to:{row:headerRow,column:lastCol}};
       ws.pageSetup={orientation:'landscape',paperSize:ws.PAPERSIZE_A4,fitToPage:true,fitToWidth:1,fitToHeight:0,horizontalCentered:true,verticalCentered:false};
       ws.pageMargins={left:0.3,right:0.3,top:0.45,bottom:0.45,header:0.2,footer:0.2};
       ws.headerFooter.oddFooter=`&L CATAT SMART · ${cls.name||'Kelas'}&C${ws.name}&RHalaman &P dari &N`;
     };

     // SHEET 1 — REKAP KESELURUHAN
     const overallHeaders=['NO','NIS/NISN','NAMA',...subs.map(s=>s.name||'Mata Pelajaran'),'RATA-RATA'];
     const ws=wb.addWorksheet('REKAP KESELURUHAN');
     ws.columns=[{width:7},{width:20},{width:34},...subs.map(()=>({width:18})),{width:17}];
     const lastOverall=overallHeaders.length;
     styleTitle(ws,lastOverall,'REKAP NILAI CATAT SMART · REKAP KESELURUHAN');
     styleMeta(ws,[['Jenjang',cls.level],['Kelas',cls.name],['Wali Kelas',cls.homeroom],['Tahun Ajaran',cls.academicYear],['Semester',cls.semester],['Tanggal Cetak',date]],lastOverall);
     const hr=10;
     overallHeaders.forEach((h,i)=>ws.getCell(hr,i+1).value=h);styleHeader(ws,hr,lastOverall);
     cls.students.forEach((st,i)=>{
       const r=hr+1+i;const vals=[i+1,st.nis||st.nisn||'',st.name,...subs.map(sub=>{const v=subjectAverage(st,sub.id);return v===null?null:Number(v.toFixed(1))}),(()=>{const v=overallAverage(st,cls);return v===null?null:Number(v.toFixed(1))})()];
       vals.forEach((v,j)=>ws.getCell(r,j+1).value=v);
     });
     styleRows(ws,hr+1,hr+cls.students.length,lastOverall,3);
     const ar=hr+1+cls.students.length;ws.mergeCells(ar,1,ar,3);ws.getCell(ar,1).value='RATA-RATA KELAS';
     subs.forEach((sub,i)=>{const av=cls.students.map(s=>subjectAverage(s,sub.id)).filter(v=>v!==null);ws.getCell(ar,4+i).value=av.length?Number((av.reduce((a,b)=>a+b,0)/av.length).toFixed(1)):null;});
     const allAvg=cls.students.map(s=>overallAverage(s,cls)).filter(v=>v!==null);ws.getCell(ar,lastOverall).value=allAvg.length?Number((allAvg.reduce((a,b)=>a+b,0)/allAvg.length).toFixed(1)):null;
     for(let c=1;c<=lastOverall;c++){const cell=ws.getCell(ar,c);cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.blue}};cell.font={name:'Aptos',bold:true,size:10,color:{argb:C.white}};cell.alignment={horizontal:'center',vertical:'middle'};cell.border={top:medium,left:thin,bottom:medium,right:thin};}ws.getRow(ar).height=24;
     setup(ws,lastOverall,hr,3);

     // SUBJECT SHEETS — SAME VISUAL SYSTEM
     subs.forEach((sub,index)=>{
       const sh=wb.addWorksheet(safeSheet(sub.name,index));
       const headers=['NO','NIS/NISN','NAMA','NO ABSEN',...ASSESSMENTS.map(a=>a.short),'RATA-RATA'];
       sh.columns=[{width:7},{width:20},{width:34},{width:12},...ASSESSMENTS.map(()=>({width:13})),{width:17}];
       const last=headers.length;styleTitle(sh,last,`REKAP NILAI CATAT SMART · ${(sub.name||'MATA PELAJARAN').toUpperCase()}`);
       styleMeta(sh,[['Jenjang',cls.level],['Kelas',cls.name],['Mata Pelajaran',sub.name],['Wali Kelas',cls.homeroom],['Tahun Ajaran',cls.academicYear],['Semester',cls.semester],['Tanggal Cetak',date]],last);
       const h=11;headers.forEach((x,i)=>sh.getCell(h,i+1).value=x);styleHeader(sh,h,last);
       cls.students.forEach((st,i)=>{const r=h+1+i;const g=(st.grades&&st.grades[sub.id])||emptyGrades();const vals=[i+1,st.nis||st.nisn||'',st.name,st.number||i+1,...ASSESSMENTS.map(a=>g[a.id]===''?null:Number(g[a.id])),(()=>{const v=subjectAverage(st,sub.id);return v===null?null:Number(v.toFixed(1))})()];vals.forEach((v,j)=>sh.getCell(r,j+1).value=v);});
       styleRows(sh,h+1,h+cls.students.length,last,3);
       const rr=h+1+cls.students.length;sh.mergeCells(rr,1,rr,3);sh.getCell(rr,1).value='RATA-RATA KELAS';const stat=classSubjectStats(cls,sub);sh.getCell(rr,4).value=stat.avg===null?null:Number(stat.avg.toFixed(1));for(let c=1;c<=last;c++){const cell=sh.getCell(rr,c);cell.fill={type:'pattern',pattern:'solid',fgColor:{argb:C.blue}};cell.font={name:'Aptos',bold:true,size:10,color:{argb:C.white}};cell.alignment={horizontal:'center',vertical:'middle'};cell.border={top:medium,left:thin,bottom:medium,right:thin};}sh.getRow(rr).height=24;
       setup(sh,last,h,4);
     });

     const buf=await wb.xlsx.writeBuffer();
     dl(buf,`Rekap_${classSafeName(cls)}_${today()}.xlsx`,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
   }catch(e){alert('Gagal membuat Excel kelas: '+(e?.message||e))}
 };
 const exportPDF=()=>exportClassPDF(activeClass);
 const exportExcel=()=>exportClassExcel(activeClass);
 const printReport=()=>{const rows=students.map((s,i)=>`<tr><td>${i+1}</td><td>${s.nis||s.nisn||''}</td><td>${s.name}</td>${ASSESSMENTS.map(a=>`<td>${gradeOf(s)[a.id]||'-'}</td>`).join('')}<td>${fmt(average(gradeOf(s)))}</td></tr>`).join('');const w=window.open('','_blank');if(!w){alert('Izinkan pop-up untuk mencetak.');return}w.document.write(`<html><head><title>Rekap CATAT SMART</title><style>body{font-family:Arial;padding:24px}h1{margin:0 0 8px;color:#0f766e}table{border-collapse:collapse;width:100%;font-size:11px}th,td{border:1px solid #ccc;padding:6px;text-align:center}th{background:#0f766e;color:white}td:nth-child(3){text-align:left}small{color:#666}</style></head><body><h1>REKAP NILAI CATAT SMART</h1><p><b>Jenjang:</b> ${activeClass.level||'-'} &nbsp; <b>Kelas:</b> ${activeClass.name||'-'} &nbsp; <b>Mapel:</b> ${activeSubject?.name||'-'}<br><b>Wali:</b> ${activeClass.homeroom||'-'} &nbsp; <b>Tahun:</b> ${activeClass.academicYear||'-'} &nbsp; <b>Semester:</b> ${activeClass.semester||'-'}</p><table><thead><tr>${['NO','NIS/NISN','NAMA','ABSEN',...ASSESSMENTS.map(a=>a.short),'AVG'].map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table><script>window.onload=()=>window.print()<\/script></body></html>`);w.document.close()};
 const shareReport=async()=>{const av=students.map(s=>average(gradeOf(s))).filter(x=>x!==null);const textShare=`Rekap CATAT SMART\nKelas: ${activeClass.name}\nMapel: ${activeSubject?.name||'-'}\nSiswa: ${students.length}\nRata-rata kelas: ${fmt(av.length?av.reduce((a,b)=>a+b,0)/av.length:null)}`;if(navigator.share){try{await navigator.share({title:'Rekap CATAT SMART',text:textShare})}catch(e){}}else{await navigator.clipboard?.writeText(textShare);alert('Ringkasan rekap disalin.')} };
 const backup=()=>dl(JSON.stringify(data,null,2),`Backup_CATAT_SMART_${today()}.json`,'application/json');
 const restore=e=>{const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const d=migrate(JSON.parse(r.result));if(!d?.classes)throw 0;if(confirm('Data saat ini akan diganti dengan backup ini?'))setData(d)}catch(x){alert('Backup tidak valid.')}};r.readAsText(f);e.target.value=''};

 const nav=(id)=>{setTab(id);setMenu(false)};
 const selectClass=(id)=>setData(d=>{const c=d.classes.find(x=>x.id===id);return {...d,activeClassId:id,classes:d.classes.map(x=>x.id===id?{...x,activeSubjectId:x.activeSubjectId||(x.subjects?.[0]?.id||null)}:x)}});
 const selectSubject=(id,classId=activeClass.id)=>setData(d=>({...d,classes:d.classes.map(c=>c.id===classId?{...c,activeSubjectId:id}:c)}));
 const tabBtn=(id,label,icon)=><button onClick={()=>setTab(id)} className={`flex-1 py-2 flex flex-col items-center gap-1 rounded-xl transition-colors ${tab===id?'text-brand-light dark:text-blue-200':'text-gray-400'}`}><span className="text-lg leading-none">{icon}</span>{label}</button>;
 const menuItem=(label,fn)=><button onClick={fn} className="w-full text-left px-4 py-3 text-sm hover:bg-gray-100 dark:hover:bg-gray-700 border-t first:border-t-0 border-gray-100 dark:border-gray-700">{label}</button>;
 const openNewClass=()=>{setClassForm(newClass());setShowClass(true);setMenu(false)};
 const openNewSubject=()=>{setSubjectForm({});setShowSubject(true);setMenu(false)};
 const openEditClass=()=>{setClassForm({...activeClass});setShowClass(true);setMenu(false)};
 const openNewStudent=()=>{setStudentForm({name:'',nis:'',nisn:'',number:'',classId:data.activeClassId});setShowStudent(true);setMenu(false)};
 const openBatchStudent=()=>{setBatchClassId(data.activeClassId);setBatchText('');setShowBatchStudent(true);setMenu(false)};
 const daftarKelas=()=> <div className="screen-panel screen-scroll flex-1 min-h-0 bg-gray-50 dark:bg-gray-900 overflow-y-scroll hide-scrollbar p-4 space-y-3">
   <div className="flex items-center justify-between"><div><div className="text-xs text-gray-500">Daftar kelas</div><h2 className="text-xl font-black">{data.classes.length} Kelas</h2></div><button onClick={openNewClass} className="bg-brand-light text-white rounded-xl px-4 py-2 text-sm font-bold">＋ Kelas</button></div>
   {data.classes.map(c=><div key={c.id} className={`class-card-stagger bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border ${c.id===data.activeClassId?'border-brand-light':'border-transparent'}`}>
     <button onClick={()=>selectClass(c.id)} className="w-full text-left"><div className="flex items-start justify-between gap-3"><div><div className="font-bold text-base">{c.name||'Tanpa nama'}</div><div className="text-xs text-gray-500 mt-1">{c.level||'-'} · {(c.subjects||[]).length} mata pelajaran</div></div><span className="text-xs font-bold text-brand-light">{c.students.length} siswa</span></div><div className="text-[11px] text-gray-400 mt-2">{c.academicYear||'-'} · {c.semester||'-'} {c.id===data.activeClassId?' · AKTIF':''}</div></button>
     <div className="mt-3 flex flex-wrap gap-2">{(c.subjects||[]).map(sub=><button key={sub.id} onClick={()=>{selectClass(c.id);selectSubject(sub.id,c.id);setTab('chat')}} className={`px-3 py-1.5 rounded-full text-xs font-bold ${sub.id===c.activeSubjectId&&c.id===data.activeClassId?'bg-brand-light text-white':'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200'}`}>{sub.name}</button>)}<button onClick={()=>{selectClass(c.id);setSubjectForm({});setShowSubject(true)}} className="px-3 py-1.5 rounded-full text-xs font-bold border border-dashed border-brand-light text-brand-light">＋ Mata Pelajaran</button></div>
     <div className="grid grid-cols-2 gap-2 mt-3"><button onClick={()=>{setClassForm({...c});setShowClass(true)}} className="rounded-lg bg-gray-100 dark:bg-gray-700 py-2 text-xs font-bold">Edit</button><button onClick={()=>{selectClass(c.id);setTab('nilai')}} className="rounded-lg bg-brand-light text-white py-2 text-xs font-bold">Data Siswa</button><button onClick={()=>{setBatchClassId(c.id);setBatchText('');setShowBatchStudent(true)}} className="rounded-lg bg-blue-50 dark:bg-blue-950/40 text-brand-light py-2 text-xs font-bold">＋ Banyak Siswa</button><button onClick={()=>exportClassExcel(c)} className="rounded-lg bg-blue-50 dark:bg-blue-950/40 text-brand-light py-2 text-xs font-bold">Excel Kelas</button><button onClick={()=>exportClassPDF(c)} className="col-span-2 rounded-lg bg-blue-600 text-white py-2 text-xs font-bold">PDF Kelas</button></div>
   </div>)}
 </div>;
 const dashboard=()=> <div className="screen-panel screen-scroll flex-1 min-h-0 p-4 space-y-4 overflow-y-scroll hide-scrollbar">
   <div className="grid grid-cols-2 gap-3">
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><div className="text-xs text-gray-500">Jumlah siswa</div><div className="text-2xl font-black text-brand-light">{students.length}</div></div>
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><div className="text-xs text-gray-500">Jumlah kelas</div><div className="text-2xl font-black text-brand-light">{data.classes.length}</div></div>
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><div className="text-xs text-gray-500">Nilai belum lengkap</div><div className="text-2xl font-black text-amber-500">{missing}</div></div>
    <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><div className="text-xs text-gray-500">Rata-rata kelas</div><div className="text-2xl font-black text-emerald-600">{fmt(students.length?students.map(s=>average(gradeOf(s))).filter(x=>x!==null).reduce((a,b)=>a+b,0)/Math.max(1,students.map(s=>average(gradeOf(s))).filter(x=>x!==null).length):null)}</div></div>
   </div>
   <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><div className="text-xs text-gray-500 mb-1">Kelas aktif</div><div className="font-bold text-lg">{activeClass.name||'Belum diberi nama'}</div><div className="text-xs text-gray-500 mt-1">{activeClass.level||'-'} · {activeSubject?.name||'Mata pelajaran belum dibuat'}</div></div>
   <div className="bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm"><h3 className="font-bold text-sm mb-3">Rekap nilai terbaru</h3>{students.filter(s=>average(gradeOf(s))!==null).slice(-5).reverse().map(s=><div key={s.id} className="flex justify-between py-2 border-t border-gray-100 dark:border-gray-700 text-sm"><span>{s.name}</span><b>{fmt(average(gradeOf(s)))}</b></div>)}{!students.some(s=>average(gradeOf(s))!==null)&&<p className="text-xs text-gray-400">Belum ada nilai yang dicatat.</p>}</div>
 </div>;
 const pencatat=()=> <div className="screen-panel flex-1 min-h-0 flex flex-col overflow-hidden screen-in">
   <div className="px-4 pt-4 pb-2 shrink-0"><div className="text-xs text-gray-500">Pencatat · Pilih kelas & mata pelajaran</div><div className="flex items-center gap-2 mt-1"><select value={data.activeClassId} onChange={e=>selectClass(e.target.value)} className="flex-1 min-w-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 font-bold text-sm focus:outline-none focus:ring-2 focus:ring-brand-light">{data.classes.map(c=><option key={c.id} value={c.id}>{c.name||'Tanpa nama'} · {c.level||'-'}</option>)}</select><span className="text-[11px] text-gray-500 whitespace-nowrap">{students.length} siswa</span></div><div className="flex items-center gap-2 mt-2"><select value={activeSubjectId||''} onChange={e=>selectSubject(e.target.value)} className="flex-1 min-w-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-brand-light"><option value="">Pilih mata pelajaran</option>{subjects.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select><button onClick={openNewSubject} className="rounded-xl bg-brand-light text-white px-3 py-2 text-xs font-bold">＋</button></div></div>
   <div className="screen-scroll flex-1 min-h-0 overflow-y-scroll overscroll-contain p-4 pt-2 space-y-3 hide-scrollbar chat-scroll">
    <div className="grid grid-cols-2 gap-3"><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Nilai terisi</div><b className="text-xl text-brand-light">{stats.filled}</b><span className="text-xs text-gray-400">/{stats.total}</span></div><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Belum lengkap</div><b className="text-xl text-amber-500">{missing}</b></div></div>
    <div className="space-y-2">{ensureMessages().map((m,i)=><div key={m.id||i} className={`flex ${m.sender==='user'?'justify-end':'justify-start'} message-in message-stagger`}><div className={`max-w-[86%] rounded-2xl px-4 py-3 shadow-sm text-sm whitespace-pre-wrap leading-5 ${m.sender==='user'?'bg-brand-light text-white rounded-br-md':'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 rounded-bl-md'}`}><div>{m.text}</div><div className={`text-[10px] mt-1 ${m.sender==='user'?'text-white/70':'text-gray-400'}`}>{m.time}</div></div></div>)}<div ref={endRef}/></div>
    <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm p-3 text-xs text-gray-500"><b className="text-gray-700 dark:text-gray-200">Pencatatan cepat</b><div className="mt-1">Ketik seperti chat: <b>Andi UH1 85</b>, <b>Siti UTS 90</b>, atau <b>UH1: Andi 85, Siti 90</b>.</div></div>
   </div>
   <form onSubmit={handleSend} className="shrink-0 p-3 bg-gray-100 dark:bg-gray-800 flex gap-2 items-end border-t border-gray-200 dark:border-gray-700"><textarea rows={Math.min(4,Math.max(1,text.split('\n').length))} value={text} onChange={e=>setText(e.target.value)} placeholder={activeSubject?'Tulis pencatatan seperti chat...':'Pilih mata pelajaran terlebih dahulu...'} disabled={!activeSubject} className="flex-1 resize-none bg-white dark:bg-gray-700 dark:text-gray-100 rounded-2xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-brand-light text-sm chat-input"/><button type="submit" disabled={!text.trim()||!activeSubject} className="bg-brand-light text-white rounded-full w-12 h-12 flex-none flex items-center justify-center disabled:opacity-50 active:scale-95 transition-transform">➤</button></form>
 </div>;
 const nilai=()=> <div className="screen-panel flex-1 min-h-0 flex flex-col bg-gray-50 dark:bg-gray-900"><div className="p-3 shrink-0 border-b border-gray-200 dark:border-gray-800 text-sm space-y-2"><div className="flex justify-between items-center"><b>{students.length} Siswa</b><div className="flex gap-2"><button onClick={openBatchStudent} className="text-brand-light font-bold">＋ Banyak</button><button onClick={openNewStudent} className="text-brand-light font-bold">＋ Siswa</button></div></div><select value={data.activeClassId} onChange={e=>selectClass(e.target.value)} className="w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-brand-light">{data.classes.map(c=><option key={c.id} value={c.id}>{c.name||'Tanpa nama'} · {c.level||'-'}</option>)}</select><div className="flex gap-2"><select value={activeSubjectId||''} onChange={e=>selectSubject(e.target.value)} className="flex-1 min-w-0 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 py-2 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-brand-light"><option value="">Pilih mata pelajaran</option>{subjects.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select><button onClick={openNewSubject} className="rounded-xl bg-brand-light text-white px-3 py-2 text-xs font-bold">＋</button></div></div><div className="nilai-scroll flex-1 min-h-0 overflow-auto touch-pan-y"><div className="min-w-max"><table className="text-xs"><thead className="bg-gray-100 dark:bg-gray-800 sticky top-0 z-10"><tr><th className="px-2 py-2 text-left sticky left-0 bg-gray-100 dark:bg-gray-800">NAMA</th><th className="px-2 py-2">ABS</th>{ASSESSMENTS.map(e=><th key={e.id} className="px-2 py-2 text-center">{e.short}</th>)}<th className="px-2 py-2 text-center text-brand-light">AVG</th></tr></thead><tbody className="nilai-stagger">{students.map((s,i)=>{const g=gradeOf(s);return <tr key={s.id} onClick={()=>setEditingStudent({...s,...g,__gradeSubjectId:activeSubjectId})} className="border-t border-gray-100 dark:border-gray-800 active:bg-brand-light/10 cursor-pointer"><td className="px-2 py-2 whitespace-nowrap font-semibold sticky left-0 bg-gray-50 dark:bg-gray-900">{s.name}</td><td className="px-2 py-2 text-center">{s.number||i+1}</td>{ASSESSMENTS.map(e=><td key={e.id} className={`px-2 py-2 text-center font-bold ${g[e.id]!==''?(+g[e.id]<60?'text-red-500':'text-brand-light'):'text-gray-300 dark:text-gray-600'}`}>{g[e.id]!==''?g[e.id]:'-'}</td>)}<td className="px-2 py-2 text-center font-bold">{fmt(average(g))}</td></tr>})}</tbody></table></div></div></div>;
 const rekap=()=> <div className="screen-panel screen-scroll flex-1 min-h-0 bg-gray-50 dark:bg-gray-900 overflow-y-scroll hide-scrollbar p-4 space-y-4"><div className="grid grid-cols-2 gap-3"><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Nilai terisi</div><div className="text-xl font-bold text-brand-light">{stats.filled}<span className="text-xs text-gray-400">/{stats.total}</span></div></div><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><div className="text-xs text-gray-500">Murid belum lengkap</div><div className="text-xl font-bold text-amber-500">{missing}</div></div></div><div className="grid grid-cols-2 gap-2"><button onClick={()=>exportClassExcel(activeClass)} className="bg-white dark:bg-gray-800 rounded-xl p-3 text-sm font-bold shadow-sm">📊 Excel Kelas</button><button onClick={()=>exportClassPDF(activeClass)} className="bg-white dark:bg-gray-800 rounded-xl p-3 text-sm font-bold shadow-sm">📄 PDF Kelas</button><button onClick={printReport} className="bg-white dark:bg-gray-800 rounded-xl p-3 text-sm font-bold shadow-sm">🖨️ Cetak</button><button onClick={shareReport} className="bg-white dark:bg-gray-800 rounded-xl p-3 text-sm font-bold shadow-sm">↗️ Bagikan</button></div><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><h3 className="font-bold text-sm mb-2">Rata-rata per penilaian</h3>{stats.per.map(p=><div key={p.id} className="mb-2"><div className="flex justify-between text-xs mb-1"><span>{p.short} <span className="text-gray-400">({p.n})</span></span><span className="font-bold">{fmt(p.avg)}{p.n?<span className="text-gray-400 font-normal"> · {p.min}–{p.max}</span>:''}</span></div><div className="h-2 rounded-full bg-gray-200 dark:bg-gray-700"><div className="h-2 rounded-full bg-brand-light" style={{width:`${p.avg||0}%`}}/></div></div>)}</div><div className="bg-white dark:bg-gray-800 rounded-xl p-3 shadow-sm"><h3 className="font-bold text-sm mb-2">Peringkat</h3>{stats.ranked.length?stats.ranked.map((r,i)=><div key={r.s.id} className="flex justify-between text-sm py-1.5 border-t first:border-t-0 border-gray-100 dark:border-gray-700"><span>{i<3?['🥇','🥈','🥉'][i]:`${i+1}.`} {r.s.name}</span><b>{fmt(r.a)}</b></div>):<p className="text-xs text-gray-400">Belum ada nilai.</p>}</div></div>;

 return <Frame dark={dark}><div className="app-shell w-full max-w-md h-full max-h-full bg-white dark:bg-gray-900 dark:text-gray-100 shadow-2xl sm:rounded-3xl overflow-hidden flex flex-col relative min-h-0"><header className="bg-brand-light dark:bg-brand-dark text-white p-4 shadow-md z-20 flex justify-between items-center"><div className="flex items-center gap-3"><img src="icon-192.png" className="w-10 h-10 rounded-xl" alt="CATAT SMART"/><div><div className="text-lg font-bold leading-tight">CATAT SMART</div><div className="text-[10px] opacity-90 tracking-widest">ASISTEN NILAI</div></div></div><div className="flex items-center gap-1"><div className="w-3 h-3 rounded-full bg-green-400"/><button onClick={()=>setDark(!dark)} className="p-2">{dark?'☀️':'🌙'}</button><div className="relative" ref={menuRef}><button onClick={()=>setMenu(v=>!v)} className="p-2 font-bold">⋮</button>{menu&&<div className="absolute right-0 top-12 w-64 bg-white dark:bg-gray-800 rounded-xl shadow-2xl overflow-hidden z-50 text-gray-800 dark:text-gray-100 border border-gray-100 dark:border-gray-700">{menuItem('🏠 Dashboard',()=>nav('chat'))}{menuItem('👨‍🎓 Data Siswa',()=>{setMenu(false);setTab('nilai')})}{menuItem('🏫 Daftar Kelas',()=>nav('kelas'))}{menuItem('✏️ Kelola Kelas',openEditClass)}{menuItem('➕ Tambah Kelas',openNewClass)}{menuItem('👥 Tambah Banyak Siswa',openBatchStudent)}{menuItem('📚 Tambah Mata Pelajaran',openNewSubject)}{menuItem('📊 Download Excel Kelas',()=>{setMenu(false);exportClassExcel(activeClass)})}{menuItem('📄 Download PDF Kelas',()=>{setMenu(false);exportClassPDF(activeClass)})}{menuItem('🖨️ Cetak / PDF',printReport)}{menuItem('↗️ Bagikan Rekap',shareReport)}{menuItem('💾 Backup Data',backup)}{menuItem('📂 Restore Data',()=>fileRef.current?.click())}{menuItem(pin?'🔒 Ubah / Hapus PIN':'🔒 Atur PIN',()=>{setShowPin(true);setMenu(false)})}</div>}<input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={restore}/></div></div></header>
 <div className="px-4 py-2 bg-white dark:bg-gray-900 border-b border-gray-100 dark:border-gray-800 text-xs flex justify-between"><span className="font-bold truncate">{activeClass.name||'Kelas'}</span><span className="text-gray-500 truncate ml-3">{activeClass.level||'-'} · {activeSubject?.name||'-'}</span></div>
 <div key={tab} className="app-content tab-transition flex-1 min-h-0 relative overflow-hidden bg-chat-bgLight dark:bg-chat-bgDark">{tab==='chat'?pencatat():tab==='nilai'?nilai():tab==='kelas'?daftarKelas():rekap()}</div>
 <div className="bg-brand-light dark:bg-brand-dark text-white border-t border-blue-400/30 flex justify-around p-2 text-xs font-medium z-10 tab-bar-in">{tabBtn('chat','Pencatat','💬')}{tabBtn('nilai','Nilai','📋')}{tabBtn('kelas','Kelas','🏫')}{tabBtn('rekap','Rekap','📈')}</div>

 {showClass&&<Modal title={classForm.id?'Edit Kelas':'Tambah Kelas'} onClose={()=>setShowClass(false)}><input className={inputCls} placeholder="Nama kelas (contoh: 7A)" value={classForm.name||''} onChange={e=>setClassForm({...classForm,name:e.target.value})}/><input className={inputCls} placeholder="Jenjang (TK / SD / SMP / SMA)" value={classForm.level||''} onChange={e=>setClassForm({...classForm,level:e.target.value})}/><input className={inputCls} placeholder="Tahun ajaran" value={classForm.academicYear||''} onChange={e=>setClassForm({...classForm,academicYear:e.target.value})}/><input className={inputCls} placeholder="Semester" value={classForm.semester||''} onChange={e=>setClassForm({...classForm,semester:e.target.value})}/><input className={inputCls} placeholder="Wali kelas" value={classForm.homeroom||''} onChange={e=>setClassForm({...classForm,homeroom:e.target.value})}/><button onClick={saveClass} className={btnCls}>Simpan Kelas</button>{classForm.id&&<button onClick={deleteClass} className="w-full text-red-500 text-sm py-2">Hapus Kelas</button>}</Modal>}
 {showSubject&&<Modal title={subjectForm.id?'Edit Mata Pelajaran':'Tambah Mata Pelajaran'} onClose={()=>setShowSubject(false)}><div className="text-xs text-gray-500">Kelas: <b>{activeClass.name||'-'}</b></div><input autoFocus className={inputCls} placeholder="Nama mata pelajaran (contoh: Matematika)" value={subjectForm.name||''} onChange={e=>setSubjectForm({...subjectForm,name:e.target.value})}/><button onClick={saveSubject} className={btnCls}>Simpan Mata Pelajaran</button>{subjectForm.id&&<button onClick={()=>{deleteSubject(subjectForm.id);setShowSubject(false)}} className="w-full text-red-500 text-sm py-2">Hapus Mata Pelajaran</button>}</Modal>}
 {showBatchStudent&&<Modal title="Tambah Banyak Siswa" onClose={()=>setShowBatchStudent(false)} wide>
   <div className="text-xs text-gray-500">Masukkan beberapa siswa sekaligus. Satu siswa per baris.</div>
   <select value={batchClassId||data.activeClassId} onChange={e=>setBatchClassId(e.target.value)} className={inputCls}>{data.classes.map(c=><option key={c.id} value={c.id}>{c.name||'Tanpa nama'} · {c.level||'-'}</option>)}</select>
   <textarea className={inputCls+' min-h-44 resize-y'} value={batchText} onChange={e=>setBatchText(e.target.value)} placeholder={'Nama | NIS | NISN | No Absen\nAndi | 1001 | 123456789 | 1\nBudi | 1002 | 987654321 | 2'} />
   <div className="text-[11px] text-gray-400">Kolom boleh hanya nama. Pemisah yang didukung: <b>|</b>, titik koma, atau Tab.</div>
   <button onClick={saveBatchStudents} className={btnCls}>Simpan Semua Siswa</button>
 </Modal>}
 {showStudent&&<Modal title={studentForm.id?'Edit Siswa':'Tambah Siswa'} onClose={()=>setShowStudent(false)}><input className={inputCls} placeholder="Nama siswa" value={studentForm.name||''} onChange={e=>setStudentForm({...studentForm,name:e.target.value})}/><select disabled={!!studentForm.id} value={studentForm.classId||data.activeClassId} onChange={e=>setStudentForm({...studentForm,classId:e.target.value})} className={inputCls}><option value="">Pilih kelas</option>{data.classes.map(c=><option key={c.id} value={c.id}>{c.name||'Tanpa nama'} · {c.level||'-'}</option>)}</select><input className={inputCls} placeholder="NIS" value={studentForm.nis||''} onChange={e=>setStudentForm({...studentForm,nis:e.target.value})}/><input className={inputCls} placeholder="NISN" value={studentForm.nisn||''} onChange={e=>setStudentForm({...studentForm,nisn:e.target.value})}/><input className={inputCls} placeholder="Nomor absen" inputMode="numeric" value={studentForm.number||''} onChange={e=>setStudentForm({...studentForm,number:e.target.value})}/><button onClick={saveStudent} className={btnCls}>Simpan Siswa</button></Modal>}
 {editingStudent&&<Modal title="Edit Siswa & Nilai" onClose={()=>setEditingStudent(null)}><input className={inputCls} value={editingStudent.name||''} onChange={e=>setEditingStudent({...editingStudent,name:e.target.value})}/><div className="grid grid-cols-2 gap-2"><input className={inputCls} placeholder="NIS" value={editingStudent.nis||''} onChange={e=>setEditingStudent({...editingStudent,nis:e.target.value})}/><input className={inputCls} placeholder="NISN" value={editingStudent.nisn||''} onChange={e=>setEditingStudent({...editingStudent,nisn:e.target.value})}/><input className={inputCls} placeholder="No absen" value={editingStudent.number||''} onChange={e=>setEditingStudent({...editingStudent,number:e.target.value})}/></div><div className="grid grid-cols-2 gap-2">{ASSESSMENTS.map(a=><label key={a.id} className="text-xs">{a.label}<input className={inputCls+' mt-1'} type="number" min="0" max="100" inputMode="numeric" value={editingStudent[a.id]??''} onChange={e=>setEditingStudent({...editingStudent,[a.id]:e.target.value})}/></label>)}</div><button onClick={()=>{const n={...editingStudent};if(!n.name.trim()){alert('Nama wajib diisi');return}for(const a of ASSESSMENTS){if(n[a.id]!==''&&(isNaN(n[a.id])||+n[a.id]<0||+n[a.id]>100)){alert(`${a.label} harus 0–100`);return}}updateActiveClass(c=>({...c,students:c.students.map(s=>{if(s.id!==n.id)return s;const grades={...(s.grades||{})};grades[activeSubjectId]=Object.fromEntries(ASSESSMENTS.map(a=>[a.id,n[a.id]??'']));return {...s,name:n.name.trim(),nis:n.nis||'',nisn:n.nisn||'',number:n.number||'',grades}})}));setEditingStudent(null)}} className={btnCls}>Simpan Perubahan</button><button onClick={deleteStudent} className="w-full text-red-500 text-sm py-2">Hapus Siswa</button></Modal>}
 {showPin&&<Modal title={pin?'Ubah / Hapus PIN':'Atur PIN'} onClose={()=>setShowPin(false)}><input type="password" inputMode="numeric" maxLength={4} className={inputCls} placeholder={pin?'PIN baru (kosongkan untuk hapus)':'PIN 4 angka'} value={pinForm.p1} onChange={e=>setPinForm({...pinForm,p1:e.target.value.replace(/\D/g,'')})}/>{(pinForm.p1||!pin)&&<input type="password" inputMode="numeric" maxLength={4} className={inputCls} placeholder="Ulangi PIN" value={pinForm.p2} onChange={e=>setPinForm({...pinForm,p2:e.target.value.replace(/\D/g,'')})}/>}<button onClick={savePin} className={btnCls}>Simpan</button></Modal>}
 </div></Frame>;
}
export default App;
