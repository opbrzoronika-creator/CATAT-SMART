# CATAT SMART V3

V3 uses the same React + Capacitor architecture pattern as the supplied NAW STUDIO project, while preserving the CATAT SMART UI from catat-smart-v5.

- Native Android shell via Capacitor
- Local React/ExcelJS dependencies (no CDN requirement)
- CATAT SMART colors/layout preserved
- NAW-style rise/pop/out motion, adapted to CATAT SMART
- UI text selection disabled; form fields remain selectable
- Excel/CSV/backup files are saved natively to Downloads on Android 10+
- localStorage data survives APK updates when Android package/signing identity stays the same
