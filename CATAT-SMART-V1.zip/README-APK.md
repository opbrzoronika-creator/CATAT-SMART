# CATAT SMART V1 APK

Project Android native WebView wrapping the CATAT SMART V1 web app.

## Build
Push to GitHub and run the **Build CATAT SMART APK** workflow. The generated debug APK is uploaded as the artifact **CATAT-SMART-debug**.

Application ID: `com.nawmanusia.catatsmart`
Version: `1.0.0`
