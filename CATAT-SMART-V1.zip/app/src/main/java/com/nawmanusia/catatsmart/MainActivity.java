package com.nawmanusia.catatsmart;
import android.app.Activity; import android.os.Bundle; import android.webkit.*;
public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle b){super.onCreate(b); webView=new WebView(this); WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); webView.setWebViewClient(new WebViewClient()); webView.loadUrl("file:///android_asset/index.html"); setContentView(webView);}
 @Override public void onBackPressed(){if(webView.canGoBack()) webView.goBack(); else super.onBackPressed();}
}
